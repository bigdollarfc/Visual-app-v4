const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const KV={get:(k,d)=>{try{const v=localStorage.getItem('visual:'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set:(k,v)=>{try{localStorage.setItem('visual:'+k,JSON.stringify(v))}catch(e){}}};
const esc2=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ESC=esc2;
let USER=null,AMODE=0,_signingIn=null;
let U=0;
function sc(k){const u=++U;return[
`<svg class="sc" viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="a${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#061233"/><stop offset=".45" stop-color="#1747b8"/><stop offset=".68" stop-color="#e9824f"/></linearGradient><radialGradient id="g${u}"><stop offset="0" stop-color="#ffd9a0"/><stop offset="1" stop-color="#ffd9a0" stop-opacity="0"/></radialGradient></defs><rect width="400" height="800" fill="url(#a${u})"/><path d="M0 560h400v240H0z" fill="#12151c"/><path d="M0 560l60-20 80 14 90-18 90 12 80-8v20H0z" fill="#0b0d12"/><circle cx="70" cy="548" r="40" fill="url(#g${u})"/><circle cx="330" cy="552" r="34" fill="url(#g${u})"/><path d="M0 700l400-60v30L0 770z" fill="#1b1f29"/></svg>`,
`<svg class="sc" viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="a${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8d9fb8"/><stop offset=".5" stop-color="#c9d1da"/></linearGradient><linearGradient id="l${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4f8f8a"/><stop offset="1" stop-color="#1c4d52"/></linearGradient></defs><rect width="400" height="800" fill="url(#a${u})"/><path d="M0 420l70-170 50 60 60-110 90 150 60-60 70 130v200H0z" fill="#6c7a8c"/><path d="M0 470l90-90 60 50 80-80 100 100 70-40v200H0z" fill="#3e5560"/><path d="M0 500c60-30 120-10 200-30s140 10 200-10v400H0z" fill="#1f3a30"/><rect y="560" width="400" height="240" fill="url(#l${u})"/><path d="M250 520h110v30H250z" fill="#5a4030"/><path d="M240 520l65-34 65 34z" fill="#3d2a20"/></svg>`,
`<svg class="sc" viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="a${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a0f2e"/><stop offset=".5" stop-color="#d24a55"/><stop offset=".8" stop-color="#ffb66b"/></linearGradient></defs><rect width="400" height="800" fill="url(#a${u})"/><circle cx="200" cy="470" r="70" fill="#ffd28a"/><path d="M0 520c80-40 140-10 200-30s130-20 200 10v300H0z" fill="#3a1a2e"/><path d="M0 600c100-40 180 0 260-20s100-10 140 0v220H0z" fill="#241022"/></svg>`,
`<svg class="sc" viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="a${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b3b4a"/><stop offset="1" stop-color="#7be0c3"/></linearGradient></defs><rect width="400" height="800" fill="url(#a${u})"/><circle cx="120" cy="300" r="90" fill="#bff7e6" opacity=".35"/><path d="M0 560c70-60 130-60 200 0s130 60 200 0v240H0z" fill="#0a2a33"/></svg>`][k%4]}
let mediaWarningShown=false,FEED_SOUND=false,MUTE_PAUSED_CARD=null;
function mediaFallback(video,scene){try{console.warn('Video failed to load:',video.currentSrc||video.src,video.error&&{code:video.error.code,message:video.error.message})}catch(e){}if(!mediaWarningShown){mediaWarningShown=true;toast('A video could not load. Check its Supabase Storage bucket and file.')}const c=video.closest('.card');if(c)c.remove();else video.remove()}
function audioIcon(soundOn){return soundOn?'<svg viewBox="0 0 24 24"><path d="M11 5 6 9H3v6h3l5 4zM15 9a5 5 0 0 1 0 6M18 6a9 9 0 0 1 0 12"/></svg>':'<svg viewBox="0 0 24 24"><path d="M11 5 6 9H3v6h3l5 4zM16 9l5 6m0-6-5 6"/></svg>'}
function syncAudioButton(card){const button=card.querySelector('[data-k=audio]');if(!button)return;button.classList.toggle('sound-on',FEED_SOUND);button.setAttribute('aria-label',FEED_SOUND?'Mute video':'Turn sound on');button.innerHTML=audioIcon(FEED_SOUND)}
function playFeedVideo(video,card){const result=video.play();if(result&&typeof result.catch==='function')result.catch(()=>{if(!video.muted){FEED_SOUND=false;video.muted=true;$$('.card').forEach(syncAudioButton);if(card.classList.contains('on'))toast('Tap the sound button to enable audio');video.play().catch(()=>{})}})}
const vKey=v=>String(v&&((v.id!=null?'id:'+v.id:null)||(v.storage_path||v.vid||v.cap&&('c:'+v.cap+':'+(v.h||v.n||'')))||JSON.stringify([v&&v.n,v&&v.cap,v&&v.s])));
function vSnap(v){return {key:vKey(v),id:v.id||null,storage_path:v.storage_path||null,vid:v.vid||'',s:v.s||0,n:v.n||'',h:v.h||'',cap:v.cap||'',tg:v.tg||'',l:v.l||0,c:v.c||0,sh:v.sh||0,col:v.col||'#3b73f2'}}
const hasLike=v=>KV.get('liked',[]).some(x=>x.key===vKey(v));
const hasSave=v=>KV.get('saved',[]).some(x=>x.key===vKey(v));
const hasRepost=v=>KV.get('reposts',[]).some(x=>x.key===vKey(v));
function setLike(v,on){let a=KV.get('liked',[]).filter(x=>x.key!==vKey(v));if(on)a.unshift(vSnap(v));KV.set('liked',a.slice(0,200));if($('#profile')&&$('#profile').classList.contains('show')){const i=$$('#ptabs button').findIndex(b=>b.getAttribute('aria-selected')==='true');if(i===2)prof(2)}}
function setSave(v,on){let a=KV.get('saved',[]).filter(x=>x.key!==vKey(v));if(on)a.unshift(vSnap(v));KV.set('saved',a.slice(0,200));if($('#profile')&&$('#profile').classList.contains('show')){const i=$$('#ptabs button').findIndex(b=>b.getAttribute('aria-selected')==='true');if(i===3)prof(3)}}
function setRepost(v,on){let a=KV.get('reposts',[]).filter(x=>x.key!==vKey(v));if(on)a.unshift(vSnap(v));KV.set('reposts',a.slice(0,200));if($('#profile')&&$('#profile').classList.contains('show')){const i=$$('#ptabs button').findIndex(b=>b.getAttribute('aria-selected')==='true');if(i===1)prof(1)}}
function renderThumbs(list,empty){list=(list||[]).filter(m=>m.vid);return list&&list.length?list.map(m=>`<div class='th'>${m.vid?`<video class='mine-vid' data-scene='${m.s||0}' src='${encodeURI(m.vid)}#t=0.1' muted playsinline preload='metadata'></video>`:sc(m.s||0)}<span class='view glass'>${esc2(m.n||'')}</span><div class='ov'>${esc2(m.cap||'')}</div></div>`).join(''):`<p class='sub'>${empty}</p>`}
const I={heart:'<svg viewBox="0 0 24 24"><path d="M12 20.5S3.5 15 3.5 9A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8.5 2c0 6-8.5 11.5-8.5 11.5z"/></svg>',chat:'<svg viewBox="0 0 24 24"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg>',save:'<svg viewBox="0 0 24 24"><path d="M6 4h12v17l-6-4-6 4z"/></svg>',share:'<svg viewBox="0 0 24 24"><path d="M5 12v7h14v-7M12 15V3M8 7l4-4 4 4"/></svg>',repost:'<svg viewBox="0 0 24 24"><path d="M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3"/></svg>',note:'<svg viewBox="0 0 24 24"><path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg>'};
const VER=['Eddy Hutt','Maya Chen'],PROFILE_PICS=new Map();let MY_USERNAME='';const vb=n=>VER.includes(n)?`<span class='vb' role='img' aria-label='Verified'><svg viewBox='0 0 24 24'><path d='M5 12.5l4.5 4.5L19 7.5'/></svg></span>`:'';
const fmt=n=>n>=1000?(n/1000).toFixed(1).replace('.0','')+'K':String(n);
const av=(n,c,x='',picture=PROFILE_PICS.get(n))=>{const initials=String(n||'User').split(' ').map(w=>w[0]||'').join('');const img=picture?`<img src="${String(picture).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}" alt="" aria-hidden="true">`:'';return `<span class="av" style="background:${c};${x}">${img}${initials}</span>`};
const FY=[],FO=[];
const LIVE=[['Eddy Hutt','Blue hour walk, ask me anything',1240,'#3b73f2',0],['Sam Ortiz','Cooking dinner for six',860,'#c2473f',2],['Lena Park','Open water swim recap',412,'#7a4fd6',3],['Maya Chen','Packing for no-signal week',233,'#1f9d7a',1]];
const feed=$('#feed');let io;
/* ---- loading state: black screen + small animated Visual logo ---- */
const VLOGO='<span class="vl"><img src="logo-loader.png" alt="" width="30" height="30" decoding="async"></span>';
const VLOAD='<div class="vload" role="status" aria-label="Loading video">'+VLOGO+'</div>';
let feedRetryT=null;
function feedLoad(msg){if(!feed)return;feed.innerHTML='<div class="feedload" role="status" aria-label="Loading videos">'+VLOGO+(msg?'<p>'+msg+'</p>':'')+'</div>'}
function scheduleFeedRetry(){if(feedRetryT)return;feedRetryT=setTimeout(()=>{feedRetryT=null;if(!FY.length)loadPublicFeed().catch(()=>{})},navigator.onLine?5000:60000)}
window.addEventListener('online',()=>{clearTimeout(feedRetryT);feedRetryT=null;if(!FY.length&&sb)loadPublicFeed().catch(()=>{});$$('.card.loading').forEach(c=>c._retry&&c._retry())});
function bindVideoLoading(vd,el,v){
 let stT,retT,tries=0;
 const setL=(on,rebuf)=>{el.classList.toggle('loading',on);el.classList.toggle('rebuf',!!(on&&rebuf))};
 const ready=()=>{clearTimeout(stT);clearTimeout(retT);tries=0;setL(false)};
 const stall=()=>{clearTimeout(stT);stT=setTimeout(()=>{if(vd.readyState<2||(!vd.paused&&vd.readyState<3))setL(true,vd.currentTime>0)},350)};
 ['loadeddata','canplay','playing'].forEach(e=>vd.addEventListener(e,ready));
 ['waiting','stalled'].forEach(e=>vd.addEventListener(e,stall));
 const retry=()=>{clearTimeout(retT);setL(true,vd.currentTime>0);vd.load();if(el.classList.contains('on')&&!el.classList.contains('paused')&&typeof playFeedVideo==='function')playFeedVideo(vd,el)};
 el._retry=retry;
 vd.addEventListener('error',()=>{
  const code=vd.error&&vd.error.code,net=code===2||!navigator.onLine;
  if(!net){mediaFallback(vd,v.s);return}
  setL(true,vd.currentTime>0);
  if(navigator.onLine){if(tries++<4)retT=setTimeout(retry,1500*tries);else mediaFallback(vd,v.s)} /* offline: wait for the 'online' event */
 });
}
function build(list,emptyMessage='No videos here yet.'){
 if(!feed)return;
 feed.innerHTML=''; if(io) try{io.disconnect()}catch(e){}
 const items=(list||[]).filter(v=>v&&v.vid);if(!items.length){feed.innerHTML=`<div class="feedempty"><b>${esc2(emptyMessage||'No videos yet.')}</b><span>Tap + to record the first one.</span></div>`;return}
 io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){$$('.card').forEach(c=>c.classList.remove('on'));x.target.classList.add('on');x.target.classList.remove('paused')}}),{root:feed,threshold:.6});
 items.forEach((v,i)=>{ if(!v)return; if(v.c==null)v.c=0; if(v.sh==null)v.sh=0; if(v.l==null)v.l=0; if(v.sv==null)v.sv=0;
  const el=document.createElement('section');el.className='card'+(i?'':' on')+(v.vid?' loading':''); el._v=v;
  const whoMeta=`data-uid="${esc2(v.user_id||'')}" data-h="${esc2(v.h||'')}" data-n="${esc2(v.n||'')}"`;
  el.innerHTML=`${v.vid?`<video class="vid" src="${esc2(v.vid)}" autoplay muted loop playsinline></video>${VLOAD}`:sc(v.s||0)}<div class="shade"></div><div class="pause glass"><svg viewBox="0 0 24 24"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg></div>
  <div class="rail"><button class="act" data-k="like" aria-pressed="${hasLike(v)?'true':'false'}" aria-label="Like"><span class="ib glass">${I.heart}</span><span class="n">${fmt(v.l||0)}</span></button><button class="act" data-k="cm" aria-label="Comments"><span class="ib glass">${I.chat}</span><span class="n">${fmt(v.c||0)}</span></button><button class="act" data-k="save" aria-pressed="${hasSave(v)?'true':'false'}" aria-label="Save"><span class="ib glass">${I.save}</span><span class="n">${hasSave(v)?'Saved':'Save'}</span></button><button class="act" data-k="sh" aria-label="Share"><span class="ib glass">${I.share}</span><span class="n">${v.sh?fmt(v.sh):'Share'}</span></button><button class="sound-toggle${FEED_SOUND?' sound-on':''}" data-k="audio" aria-label="${v.vid?(FEED_SOUND?'Mute video':'Turn sound on'):'No video audio'}" ${v.vid?'':'disabled'}>${audioIcon(FEED_SOUND)}</button><button class="disc" data-k="snd" aria-label="View sound"><span class="groove"><i></i></span></button></div>
  <div class="info">${v.rp&&typeof rpHTML==='function'?rpHTML(v.rp,v.rc):''}${hasRepost(v)&&typeof rpHTML==='function'?rpHTML('You','#3b73f2'):''}<div class='who row'><div class='avw'>${av(v.n,v.col||'#3b73f2','width:38px;height:38px',v.avatar||PROFILE_PICS.get(v.n))}${(v.h&&typeof FOLL!=='undefined'&&FOLL.has(v.h))||!v.h?'':`<button class='fplus' data-h='${esc2(v.h)}' aria-label='Follow ${esc2(v.n||'user')}'><svg viewBox='0 0 24 24'><path d='M12 5v14M5 12h14'/></svg></button>`}</div><div class="who-meta" ${whoMeta}><b>${esc2(v.n||'User')}${vb(v.n)}</b><span>@${esc2(v.h||'user')} · ${esc2(v.t||'')}</span></div></div><p class="cap">${esc2(v.cap||'')}</p><p class="tags">${esc2(v.tg||'')}${v.pr?' · Promoted':''}</p><span class="aud glass">${I.note}Original audio · ${esc2(v.n||'')}</span></div><div class="bar"><i></i></div>`;
  feed.appendChild(el);io.observe(el);
  const vd=el.querySelector('.vid');if(vd){vd.muted=!FEED_SOUND;vd.playbackRate=v.speed||1;vd.addEventListener('loadedmetadata',()=>el.classList.toggle('land',vd.videoWidth/vd.videoHeight>.8));bindVideoLoading(vd,el,v);new MutationObserver(()=>{if(el.classList.contains('paused')||!el.classList.contains('on'))vd.pause();else{vd.muted=!FEED_SOUND;vd.playbackRate=v.speed||1;if(typeof playFeedVideo==='function')playFeedVideo(vd,el); else vd.play().catch(()=>{})}}).observe(el,{attributes:true,attributeFilter:['class']})}
  let last=0;
  let lpT,lpAt=0,sx=0,sy=0;el.onpointerdown=e=>{if(e.target.closest('button,.aud,.who-meta,.avw'))return;sx=e.clientX;sy=e.clientY;lpT=setTimeout(()=>{lpAt=Date.now();navigator.vibrate&&navigator.vibrate(15);if(typeof openMenu==='function')openMenu(v,el)},500)};el.onpointermove=e=>{if(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10)clearTimeout(lpT)};['onpointerup','onpointercancel','onpointerleave'].forEach(k=>el[k]=()=>clearTimeout(lpT));el.oncontextmenu=e=>e.preventDefault();el.onclick=e=>{if(e.target.closest('button,.aud,.who-meta,.avw,.fplus')||Date.now()-lpAt<700)return;const n=Date.now();el.classList.toggle('paused');if(n-last<300&&typeof like==='function')like(el,v,1,e);last=n};
  const lk=el.querySelector('[data-k=like]'); if(lk) lk.onclick=()=>typeof like==='function'&&like(el,v,0);
  const svb=el.querySelector('[data-k=save]'); if(svb) svb.onclick=e=>{const b=e.currentTarget,on=b.getAttribute('aria-pressed')!=='true';b.setAttribute('aria-pressed',on);b.querySelector('.n').textContent=on?'Saved':'Save';if(typeof setSave==='function')setSave(v,on);if(on)toast('Saved to your collection');if(typeof toggleSavePersist==='function')toggleSavePersist(v,on)};
  const fp=el.querySelector('.fplus');if(fp)fp.onclick=(e)=>{e.stopPropagation(); if(typeof doFollow==='function')doFollow(v.h,v.user_id)};
  const cm=el.querySelector('[data-k=cm]'); if(cm) cm.onclick=()=>typeof openC==='function'&&openC(v,el);
  const sh=el.querySelector('[data-k=sh]'); if(sh) sh.onclick=e=>{e.stopPropagation();if(typeof doSharePersist==='function')doSharePersist(v);try{navigator.clipboard&&navigator.clipboard.writeText(location.href)}catch(_){}toast('Link copied')};
  const wmeta=el.querySelector('.who-meta'); if(wmeta)wmeta.onclick=e=>{e.stopPropagation();if(typeof openUserProfile==='function')openUserProfile({id:wmeta.dataset.uid,username:wmeta.dataset.h,display_name:wmeta.dataset.n})};
  const wav=el.querySelector('.avw .av, .avw > span.av'); if(wav)wav.onclick=e=>{if(e.target.closest('.fplus'))return; e.stopPropagation(); const wm=el.querySelector('.who-meta'); if(wm&&typeof openUserProfile==='function')openUserProfile({id:wm.dataset.uid,username:wm.dataset.h,display_name:wm.dataset.n})};
  const abtn=el.querySelector('[data-k=audio]'); if(abtn)abtn.onclick=async()=>{if(!vd)return;
   if(FEED_SOUND){FEED_SOUND=false;vd.muted=true;try{vd.pause()}catch(e){};if(!el.classList.contains('paused')){el.classList.add('paused');MUTE_PAUSED_CARD=el}else MUTE_PAUSED_CARD=null}
   else{FEED_SOUND=true;vd.muted=false;if(MUTE_PAUSED_CARD===el){el.classList.remove('paused');MUTE_PAUSED_CARD=null}if(el.classList.contains('on')&&!el.classList.contains('paused'))try{await vd.play()}catch(err){FEED_SOUND=false;vd.muted=true;try{vd.pause()}catch(e){};$$('.card').forEach(syncAudioButton);toast('Could not play audio')}}
   $$('.card').forEach(c=>typeof syncAudioButton==='function'&&syncAudioButton(c))};
  const snd=el.querySelector('[data-k=snd]'); if(snd)snd.onclick=()=>typeof openSound==='function'&&openSound(v);
  const aud=el.querySelector('.aud'); if(aud)aud.onclick=()=>typeof openSound==='function'&&openSound(v);
 });feed.scrollTop=0;
}
function like(el,v,dbl,e){const b=el.querySelector('[data-k=like]'); if(!b)return; const was=hasLike(v); let on=was;
 if(dbl){on=true; if(!was){setLike(v,true); v.l=Math.max(0,(v.l||0)+1); b.setAttribute('aria-pressed','true'); b.querySelector('.n').textContent=fmt(v.l); toggleLikePersist(v,true)} const r=el.getBoundingClientRect(),d=document.createElement('div');d.className='burst';d.style.left=(e?e.clientX-r.left:r.width/2)+'px';d.style.top=(e?e.clientY-r.top:r.height/2)+'px';d.innerHTML=I.heart;el.appendChild(d);setTimeout(()=>d.remove(),800); return}
 on=!was; b.setAttribute('aria-pressed',on?'true':'false'); v.l=Math.max(0,(v.l||0)+(on?1:-1)); b.querySelector('.n').textContent=fmt(v.l); setLike(v,on); toggleLikePersist(v,on)}
/* home tabs: Live, Following, For you (same for all users) */
function homeTab(i){$$('#htabs button').forEach((b,j)=>b.setAttribute('aria-selected',i===j));
 $('#live').style.display=i===0?'block':'none';feed.style.display=i===0?'none':'block';
 if(i===0)renderLiveGrid();
 if(i===1){FO.splice(0,FO.length,...FY.filter(v=>FOLL.has(v.h)));build(FO,'No videos from people you follow yet.');}if(i===2)build(FY);}
$$('#htabs button').forEach((b,i)=>b.onclick=()=>homeTab(i));
function renderLiveGrid(){if(!$('#lgrid'))return; $('#lgrid').innerHTML=LIVE.map((x,i)=>`<button class="th" data-r="${i}" style="text-align:left">${sc(x[4])}<span class="badge">LIVE</span><span class="view glass">${fmt(x[2])}</span><div class="ov"><div class="row" style="gap:8px">${av(x[0],x[3],'width:32px;height:32px;font-size:11px')}<b>${x[0]}${vb(x[0])}</b></div><div style="font-weight:500;font-size:12px;color:var(--m2)">${x[1]}</div></div></button>`).join('');$$('#lgrid [data-r]').forEach(b=>b.onclick=()=>openLive(+b.dataset.r))}
renderLiveGrid();
const chatLines=['Lena: that sky!!','Jo: hi from Austin','Priya: sending hearts','Sam: what song is this?','Alex: first time here, love it'];let ct;
$$('[data-r]').forEach(b=>b.onclick=()=>{const x=LIVE[b.dataset.r];$('#rsc').innerHTML=sc(x[4]);$('#rav').outerHTML=av(x[0],x[3],'width:36px;height:36px;font-size:13px').replace('<span','<span id="rav"');$('#rn').innerHTML=x[0]+vb(x[0]);$('#rv').textContent=fmt(x[2]);$('#rchat').innerHTML='';$('#room').classList.add('open');let k=0;ct=setInterval(()=>{const d=document.createElement('div');d.textContent=chatLines[k++%5];$('#rchat').appendChild(d);if($('#rchat').children.length>4)$('#rchat').firstChild.remove()},1400)});
$('#rx').onclick=()=>{$('#room').classList.remove('open');clearInterval(ct)};
/* discover */
$('#chips').innerHTML=['For you','Food','Travel','Outdoors','Music','Home'].map((c,i)=>`<button class="chip" aria-pressed="${!i}">${c}</button>`).join('');
$$('#chips .chip').forEach(b=>b.onclick=()=>$$('#chips .chip').forEach(x=>x.setAttribute('aria-pressed',x===b)));
$('#trend').innerHTML=[['#bluehour','48K videos'],['#nosignal','21K videos'],['#slowliving','17K videos'],['#marketday','9K videos']].map((t,i)=>`<div class="tr"><div><b>${i+1}. ${t[0]}</b></div><span>${t[1]}</span></div>`).join('');
const thumbs=(n,off=0,lab=true)=>Array.from({length:n},(_,i)=>`<div class="th">${sc(i+off)}<span class="view glass">▶ ${fmt([24800,12200,8400,3100,56000,990][(i+off)%6])}</span>${lab?`<div class="ov">${['Blue hour, no filter','Cabin, no signal','Market haul','Swim at sunrise'][(i+off)%4]}</div>`:''}</div>`).join('');
$('#dgrid').innerHTML='';
/* inbox */
const ACT=[['Eddy Hutt','#3b73f2','liked your video “Cabin, no signal”','2m',0],['Lena Park','#7a4fd6','started following you','1h',1],['Priya Nair','#c2477f','commented: “Saving this for the weekend”','3h',0],['Jo Reyes','#d98a1f','mentioned you in a comment','Yesterday',0]];
const MSG=[['Sam Ortiz','#c2473f','Can you send that market spot?','10m',1],['Lena Park','#7a4fd6','Duet this weekend?','2h',1],['Jo Reyes','#d98a1f','Thanks!','Mon',0]];
function inbox(i){const L=i?MSG:ACT;$('#ilist').innerHTML=L.map(x=>`<div class="item">${av(x[0],x[1])}<div class="t"><b>${x[0]}${vb(x[0])}</b><span>${x[2]}</span></div><small>${x[3]}</small>${i?(x[4]?'<span class="un"></span>':''):(x[4]?'<button class="btn" style="padding:7px 14px;font-size:13px;border-radius:12px" data-toast="Followed back">Follow back</button>':'')}</div>`).join('');bind()}
$$('#itabs button').forEach((b,i)=>b.onclick=()=>{$$('#itabs button').forEach(x=>x.setAttribute('aria-selected',x===b));inbox(i)});inbox(0);
/* profile */
function prof(i){$('#pgrid').innerHTML=i===0?thumbs(4,1,false):i===1?repGrid():i===2?thumbs(2,0,false):i===3?thumbs(2,2,false):[['Slow mornings','12 videos'],['No-signal trips','8 videos'],['Dinner for six','5 videos'],['Blue hour','21 videos']].map(c=>`<div class="col">${c[0]}<span>${c[1]}</span></div>`).join('')}
$$('#ptabs button').forEach((b,i)=>b.onclick=()=>{$$('#ptabs button').forEach(x=>x.setAttribute('aria-selected',x===b));prof(i);refreshProfileStatsSafe()});prof(0);refreshProfileStatsSafe();
/* repost, sound, settings */
function rpHTML(n,c){return `<div class='rp'>${av(n,c,'width:26px;height:26px;font-size:9px;border:1.5px solid #fff')}<span class='rb'>${n==='You'?'You reposted':n.toUpperCase()+' reposted'}</span><span class='rbtn glass'>${I.repost}</span></div>`}
function repGrid(){const list=KV.get('reposts',[]);return list.length?renderThumbs(list,'Videos you repost show up here.'): `<p class='sub'>Videos you repost show up here.</p>`}
function doRepost(v,el){const x=v||mV,e=el||mE;if(!x)return;const on=!hasRepost(x);setRepost(x,on);if(e){const rp=e.querySelector('.rp');if(on&&!rp)e.querySelector('.info').insertAdjacentHTML('afterbegin',rpHTML('You','#3b73f2'));if(!on&&rp)rp.remove()}toast(on?'Reposted to your profile':'Repost removed')}
$('#menuBtn').onclick=()=>{show('settings');$('#nav [data-s=profile]').setAttribute('aria-current','page')};
$('#setback').onclick=()=>show('profile');
$$('.sw').forEach(b=>b.onclick=()=>b.setAttribute('aria-checked',b.getAttribute('aria-checked')!=='true'));
let SV=[];
function openSound(v){
 const related=[v,...([...FY,...FO].filter(x=>x&&x!==v&&((v.h&&x.h===v.h)||(x.n===v.n))))].filter((x,i,a)=>x&&a.findIndex(y=>vKey(y)===vKey(x))===i).slice(0,12);
 SV=related;
 const thumb=v&&v.vid?`<video src="${esc2(v.vid)}#t=0.1" muted playsinline preload="metadata" style="width:100%;height:100%;object-fit:cover;border-radius:14px"></video>`:sc((v&&v.s)||0);
 $('#sbody').innerHTML=`<div class='row' style='gap:16px;margin:8px 0 16px'><div style='width:96px;height:96px;flex:none;overflow:hidden;border-radius:14px;background:#1b1f29'>${thumb}</div><div><h2 style='margin:0;font-size:20px'>Original audio</h2><div style='color:var(--mute)'>${esc2((v&&v.n)||'Unknown')} · ${v&&v.vid?'original video':'scene'}</div><div style='margin-top:4px'><b>${fmt((v&&v.l)||0)}</b> <span style='color:var(--mute)'>likes</span></div></div></div><div class='row'><button class='btn' style='flex:1' data-toast='Camera opens with this sound'>Use this sound</button><button class='btn o' data-toast='Added to favorites'>Add to favorites</button></div><h3>Videos with this sound</h3><div class='grid'>${SV.map((x,i)=>`<button class='th' data-p='${i}' style='text-align:left'>${x.vid?`<video src="${esc2(x.vid)}#t=0.1" muted playsinline preload="metadata" style="width:100%;height:100%;object-fit:cover"></video>`:sc(x.s||0)}<span class='view glass'>❤ ${fmt(x.l||0)}</span></button>`).join('')||'<p class="sub">No videos yet.</p>'}</div>`;
 $$('#sbody [data-p]').forEach(b=>b.onclick=()=>openPop(SV[b.dataset.p]));bind();$('#sound').classList.add('open');$('#sound').scrollTop=0}
function openPop(x){if(!x)return; $('#pop').innerHTML=`<section class='card on' style='height:100%'>${x.vid?`<video class='vid' src="${esc2(x.vid)}" autoplay loop playsinline ${typeof FEED_SOUND!=='undefined'&&FEED_SOUND?'':'muted'}></video>`:sc(x.s||0)}<div class='shade'></div><button class='ib glass' id='px' aria-label='Close' style='position:absolute;top:calc(env(safe-area-inset-top,0px) + 12px);right:16px;z-index:5'><svg viewBox='0 0 24 24'><path d='M6 6l12 12M18 6L6 18'/></svg></button><div class='info' style='right:16px'><div class='who row'>${av(x.n,x.col||'#3b73f2','width:44px;height:44px',x.avatar||PROFILE_PICS.get(x.n))}<div><b>${esc2(x.n||'')}${vb(x.n)}</b><span>${fmt(x.l||0)} likes</span></div></div><p>${esc2(x.cap||'')}</p><span class='aud glass'>${I.note}Original audio · ${esc2(x.n||'')}</span></div><div class='bar'><i></i></div></section>`;$('#pop').classList.add('open');const pv=$('#pop video'); if(pv&&!(typeof FEED_SOUND!=='undefined'&&FEED_SOUND))pv.muted=true; $('#px').onclick=()=>$('#pop').classList.remove('open')}
$('#sback').onclick=()=>$('#sound').classList.remove('open');
/* stories */
const ST=[{n:'You',own:1,col:'#3b73f2',items:[]},{n:'Eddy Hutt',col:'#3b73f2',items:[{s:0,txt:'Blue hour again',t:'2h'},{s:3,txt:'Parking lot sunsets',t:'1h'}]},{n:'Lena Park',col:'#7a4fd6',items:[{s:3,txt:'Swim day 14',t:'3h'}]},{n:'Jo Reyes',col:'#d98a1f',items:[{s:1,txt:'Ran out of road',t:'5h'},{s:0,txt:'Gas station dinner',t:'4h'},{s:2,txt:'Found it',t:'4h'}]},{n:'Priya Nair',col:'#c2477f',items:[{s:2,txt:'Slow Sunday',t:'8h'}]},{n:'Sam Ortiz',col:'#c2473f',items:[{s:2,txt:'Market run',t:'9h'}]}];
let L=[],cu=0,ci=0,stT;
function renderStories(){$('#strow').innerHTML=ST.map(u=>`<button class='stb' data-n='${u.n}'><span class='ring${u.seen?' seen':''}${u.own&&!u.items.length?' own':''}'>${av(u.own?'You':u.n,u.col,'width:100%;height:100%;font-size:18px')}${u.own?`<span class='plus'>+</span>`:''}</span><span class='sn'>${u.own?'Your story':u.n.split(' ')[0]}</span></button>`).join('');
 $$('#strow .stb').forEach(b=>b.onclick=()=>{const u=ST.find(x=>x.n===b.dataset.n);if(u.own){if(u.items.length){if(confirm('View your story? Cancel to add a new one.'))openStory(u.n);else openAddStory()}else openAddStory();return}openStory(u.n)})}
function openAddStory(pref){const p=pref||{s:0,txt:''};let pick=p.s;
 $('#mlist').innerHTML=`<h3 style='margin:0 0 4px'>Add to your story</h3><p class='sub' style='margin:0 0 10px'>Pick a look and add a short caption.</p><div class='row' id='spick' style='gap:8px;margin-bottom:12px'>${[0,1,2,3].map(k=>`<button data-k='${k}' aria-label='Look ${k+1}' style='flex:1;aspect-ratio:9/14;border-radius:12px;overflow:hidden;position:relative;outline:${k===pick?'3px solid #fff':'0'};outline-offset:2px'>${sc(k)}</button>`).join('')}</div><input class='fld' id='stxt' maxlength='80' placeholder='Add text to your story' value='${esc2(p.txt||'')}'><button class='btn' id='sadd' style='width:100%;margin-top:10px'>Add to story</button>`;
 $('#menu').classList.add('open');
 $$('#spick button').forEach(b=>b.onclick=()=>{pick=+b.dataset.k;$$('#spick button').forEach(x=>x.style.outline=x===b?'3px solid #fff':'0')});
 $('#sadd').onclick=()=>{const txt=$('#stxt').value.trim()||'New story';ST[0].items.push({s:pick,txt,t:'now'});ST[0].seen=false;closeMenu();renderStories();toast('Added to your story')}};
function openStory(n){L=ST.filter(u=>u.items.length);cu=L.findIndex(u=>u.n===n);ci=0;$('#story').classList.add('open');showStory()}
function showStory(){const u=L[cu],it=u.items[ci];clearTimeout(stT);u.seen=true;
 $('#story').innerHTML=`<section class='card on' style='height:100%'>${sc(it.s)}<div class='shade'></div><div class='segs'>${u.items.map((_,k)=>`<span><i style='${k<ci?'width:100%':k===ci?'animation:prog 4.5s linear forwards':''}'></i></span>`).join('')}</div><div class='shead row'>${av(u.own?'You':u.n,u.col,'width:36px;height:36px;font-size:13px')}<b>${u.own?'Your story':u.n}${vb(u.own?'You':u.n)}</b><small>${it.t}</small><button class='ib glass' id='sx' aria-label='Close' style='margin-left:auto'><svg viewBox='0 0 24 24'><path d='M6 6l12 12M18 6L6 18'/></svg></button></div><button class='zl' aria-label='Previous'></button><button class='zr' aria-label='Next'></button><p class='stxt'>${it.txt}</p><div class='sreply row'><input placeholder='Send a message' aria-label='Reply'><button class='ib glass' id='slk' aria-label='Like'>${I.heart}</button></div></section>`;
 $('#sx').onclick=closeStory;$('#story .zl').onclick=prevStory;$('#story .zr').onclick=nextStory;$('#slk').onclick=e=>e.currentTarget.classList.toggle('lk');
 const inp=$('#story input'),bar=()=>$$('#story .segs i')[ci];
 inp.onfocus=()=>{clearTimeout(stT);bar().style.animationPlayState='paused'};
 inp.onblur=()=>{bar().style.animationPlayState='running';stT=setTimeout(nextStory,2500)};
 inp.onkeydown=e=>{if(e.key==='Enter'&&inp.value.trim()){inp.value='';inp.blur();toast('Message sent')}};
 stT=setTimeout(nextStory,4500)}
function nextStory(){ci++;if(ci>=L[cu].items.length){cu++;ci=0}if(cu>=L.length)closeStory();else showStory()}
function prevStory(){if(ci>0)ci--;else if(cu>0){cu--;ci=0}showStory()}
function closeStory(){clearTimeout(stT);$('#story').classList.remove('open');renderStories()}
function addStory(){if(!mV){openAddStory();return}ST[0].items.push({s:mV.s,txt:mV.cap,t:'now'});ST[0].seen=false;renderStories()}
renderStories();
/* comments (user-posted only, no demo) */
let CV,CM=[],CID=100,RT=null,mE=null;
function mkC(){return []}
function find(id){id=String(id);for(const c of CM){if(String(c.id)===id)return[c,c];for(const r of (c.r||[]))if(String(r.id)===id)return[r,c]}return[]}
function cHTML(c,top){const body=c.st?`<div class='cst'>${c.st}</div>`:`<p>${tg(c.t)}</p>`;
 return `<div class='cm${top?'':' rep'}${c.new?' new':''}'>${av(c.n,c.col,top?'width:36px;height:36px;font-size:12px':'width:28px;height:28px;font-size:10px')}<div class='cb'><div><b>${esc2(c.n)}${vb(c.n)}</b>${c.n===CV.n?`<span class='crt'>Creator</span>`:''} <small>${esc2(c.w||'')}</small></div>${body}<div class='cact'><button data-lk='${c.id}' class='${c.liked?'on':''}'>${I.heart}<span data-lc='${c.id}'>${fmt(c.l||0)}</span></button><button data-rp='${c.id}'>Reply</button></div>${top&&c.r.length?`<button class='vr' data-vr='${c.id}'>${c.open?'Hide replies':'View '+c.r.length+(c.r.length>1?' replies':' reply')}</button>`:''}${top&&c.open?c.r.map(r=>cHTML(r,0)).join(''):''}</div></div>`}
function countCM(list){let n=0;(list||[]).forEach(c=>{n++; n+=countCM(c.r||[])});return n}
function renderC(){const L=$('#cl');if(!L)return;const y=L.scrollTop;L.innerHTML=CM.length?CM.map(c=>cHTML(c,1)).join(''):`<p class='sub' style='text-align:center;padding:24px 0'>No comments yet. Be the first to comment.</p>`;L.scrollTop=y;CM.forEach(c=>{c.new=0;(c.r||[]).forEach(r=>r.new=0)}); const ct=$('#ct'); if(ct&&CV)ct.textContent=fmt(CV.c||countCM(CM)||0)+' comments'}
function clearRT(){RT=null;const r=$('#rto');if(r)r.classList.remove('open')}
async function toggleCommentLike(c,btn){if(!c)return; const on=!c.liked; c.liked=on; c.l=Math.max(0,(c.l||0)+(on?1:-1)); if(btn){btn.classList.toggle('on',!!c.liked); const sp=btn.querySelector('span'); if(sp)sp.textContent=fmt(c.l)} if(!(sb&&USER&&c.dbid))return; try{ if(on){const r=await sb.from('comment_likes').insert({comment_id:c.dbid,user_id:USER.id}); if(r.error&&r.error.code!=='23505'){c.liked=!on;c.l=Math.max(0,(c.l||0)+(on?-1:1));renderC();toast('Could not like comment: '+r.error.message);return}} else {const r=await sb.from('comment_likes').delete().eq('comment_id',c.dbid).eq('user_id',USER.id); if(r.error){c.liked=!on;c.l=Math.max(0,(c.l||0)+(on?-1:1));renderC();toast('Could not unlike comment: '+r.error.message);return}} try{await sb.rpc('bump_comment_counter',{cid:c.dbid,delta:on?1:-1})}catch(e){} }catch(e){c.liked=!on;c.l=Math.max(0,(c.l||0)+(on?-1:1));renderC();toast('Could not update comment like')}}
async function postC(t,st){const meName=(ME&&ME.display_name)||(ME&&ME.username)||KV.get('name','You'); if(sb&&USER&&cloudVideoId(CV)&&!st){const parent=RT?find(RT):null; const pRow=parent&&parent[0]&&parent[0].dbid?parent[0].dbid:null; const r=await persistCommentCloud(CV,t,pRow); if(!r.ok&&!r.local){toast('Could not save comment: '+(r.error&&r.error.message||r.error||'unknown error')); return} if(r.ok){const ok=await loadCloudComments(CV); if(!ok&&r.row){const node={id:'db'+r.row.id,dbid:r.row.id,n:meName,col:'#3b73f2',avatar:(ME&&ME.avatar_url)?imgUrl(ME.avatar_url):'',t:r.row.body||t,st:'',w:'now',l:0,liked:false,r:[],parent_id:pRow,db:1,new:1}; if(pRow&&parent&&parent[0]){parent[0].r.push(node); if(parent[1])parent[1].open=true;} else CM=(CM||[]).concat([node]); CV.cm=CM;} CV.c=countCM(CM);} else {CV.c=(CV.c||0)+1} const ct=$('#ct');if(ct)ct.textContent=fmt(CV.c||countCM(CM)||0)+' comments'; syncFeedCardFor(CV); clearRT(); renderC(); await refreshProfileStatsSafe(); const cl=$('#cl'); if(cl)cl.scrollTop=cl.scrollHeight; return}
 const c={id:++CID,n:meName,col:'#3b73f2',t,st,w:'now',l:0,liked:false,r:[],new:1};if(RT){const[p,top]=find(RT);if(p){p.r.push(c); if(top)top.open=true}else CM.unshift(c)}else CM.unshift(c);CV.c=(CV.c||0)+1;const ct=$('#ct');if(ct)ct.textContent=fmt(CV.c)+' comments';syncFeedCardFor(CV);clearRT();renderC();const cl=$('#cl');if(!RT&&cl)cl.scrollTop=cl.scrollHeight}
async function sendC(){const i=$('#cinp');if(!i)return;const t=i.value.trim();if(!t)return;i.value='';const s=$('#sug');if(s)s.classList.remove('open');await postC(t,'')}
async function loadCloudComments(v){if(!(sb&&cloudVideoId(v)))return false; try{
 let r=await sb.from('video_comments').select('id,body,created_at,user_id,parent_id,likes_count,profiles:user_id(username,display_name,avatar_url)').eq('video_id',cloudVideoId(v)).order('created_at',{ascending:true}).limit(300);
 if(r.error){console.warn('loadCloudComments rich join failed, retrying',r.error); r=await sb.from('video_comments').select('id,body,created_at,user_id,parent_id,likes_count').eq('video_id',cloudVideoId(v)).order('created_at',{ascending:true}).limit(300)}
 if(r.error){console.warn('loadCloudComments retrying basic',r.error); r=await sb.from('video_comments').select('id,body,created_at,user_id').eq('video_id',cloudVideoId(v)).order('created_at',{ascending:true}).limit(300)}
 if(r.error){console.error('loadCloudComments',r.error);return false}
 const rows=r.data||[], ids=rows.map(m=>m.id); let likedSet=new Set();
 if(USER&&ids.length){try{const lr=await sb.from('comment_likes').select('comment_id').in('comment_id',ids).eq('user_id',USER.id); if(!lr.error)(lr.data||[]).forEach(x=>likedSet.add(String(x.comment_id)))}catch(e){}}
 const all=rows.map(m=>{const p=m.profiles||{}; const name=p.display_name||p.username||(m.user_id&&USER&&m.user_id===USER.id?(ME&&ME.display_name||KV.get('name','You')):'User'); return {id:'db'+m.id,dbid:m.id,n:name,col:'#3b73f2',avatar:p.avatar_url?imgUrl(p.avatar_url):'',t:m.body||'',st:'',w:ago(m.created_at),l:+(m.likes_count||0)||0,liked:likedSet.has(String(m.id)),r:[],parent_id:m.parent_id||null,db:1}});
 const map=new Map(all.map(c=>[String(c.dbid),c])); const tops=[];
 all.forEach(c=>{if(c.parent_id&&map.has(String(c.parent_id))){map.get(String(c.parent_id)).r.push(c)} else tops.push(c)});
 CM=tops; v.cm=CM; v.c=all.length; return true}catch(e){console.error(e);return false}}
async function openC(v,el){CV=v;mE=el||mE;RT=null;const P=$('#sheet .panel');P.classList.add('big');
 if(sb&&cloudVideoId(v)){try{await loadCloudComments(v)}catch(e){}} CM=v.cm=v.cm||[];
 P.innerHTML=`<div class='grab'></div><div class='chead'><div><b id='ct'>${fmt(v.c||CM.length)} comments</b></div><button class='ib' id='cx' aria-label='Close'><svg viewBox='0 0 24 24'><path d='M6 6l12 12M18 6L6 18'/></svg></button></div><div class='clist' id='cl'></div><div class='sug' id='sug'></div><div class='stk' id='stk'></div><div class='rto' id='rto'></div><div class='cin'><button class='ib' id='cst' aria-label='Stickers'>😊</button><button class='ib' id='cat' aria-label='Tag someone'>@</button><input id='cinp' placeholder='${(sb&&!USER)?'Sign in to comment':'Add a comment'}' aria-label='Add a comment' ${(sb&&!USER)?'disabled':''}><button class='btn' id='csend' ${(sb&&!USER)?'disabled':''}>Post</button></div>`;
 $('#cx').onclick=()=>$('#sheet').classList.remove('open');
 $('#cl').onclick=e=>{const g=a=>e.target.closest(`[data-${a}]`);let b;
  if(b=g('lk')){const[c]=find(b.dataset.lk);if(!c)return;toggleCommentLike(c,b)}
  else if(b=g('rp')){const[c,p]=find(b.dataset.rp);if(!c)return;RT=c.id;$('#cinp').value='@'+handle(c.n)+' ';$('#rto').innerHTML=`<span>Replying to @${esc2(handle(c.n))}</span><button id='rcx' aria-label='Cancel reply'>✕</button>`;$('#rto').classList.add('open');$('#rcx').onclick=clearRT;$('#cinp').focus()}
  else if(b=g('vr')){const[c]=find(b.dataset.vr);if(!c)return;c.open=!c.open;renderC()}};
 const inp=$('#cinp');
 inp.oninput=()=>{const m=/@(\w*)$/.exec(inp.value),s=$('#sug');if(!m){s.classList.remove('open');return}const q=m[1].toLowerCase(),F=(typeof PPL!=='undefined'?PPL:[]).filter(p=>p[0].startsWith(q)||p[1].toLowerCase().startsWith(q)).slice(0,4);if(!F.length){s.classList.remove('open');return}s.innerHTML=F.map(p=>`<button data-h='${p[0]}'>${av(p[1],p[2],'width:30px;height:30px;font-size:11px')}<span><b>${p[1]}${vb(p[1])}</b> <small style='color:var(--mute)'>@${p[0]}</small></span></button>`).join('');s.classList.add('open');$$('#sug button').forEach(b=>b.onclick=()=>{inp.value=inp.value.replace(/@(\w*)$/,'@'+b.dataset.h+' ');s.classList.remove('open');inp.focus()})};
 inp.onkeydown=e=>{if(e.key==='Enter')sendC()};$('#csend').onclick=sendC;
 $('#cat').onclick=()=>{inp.value+=(inp.value&&!inp.value.endsWith(' ')?' ':'')+'@';inp.focus();inp.oninput()};
 $('#cst').onclick=()=>$('#stk').classList.toggle('open');
 $('#stk').innerHTML=STK.map(s=>`<button data-s2='${s}'>${s}</button>`).join('');
 $$('#stk button').forEach(b=>b.onclick=()=>{$('#stk').classList.remove('open');postC('',b.dataset.s2)});
 const ct=$('#ct'); if(ct)ct.textContent=fmt(v.c||CM.length)+' comments'; syncFeedCardFor(v);
 renderC();$('#sheet').classList.add('open')}
/* menu */
const CH=`<svg viewBox='0 0 24 24'><path d='M15 5l-7 7 7 7'/></svg>`;
const PPL=[['lenapark','Lena Park','#7a4fd6'],['joreyes','Jo Reyes','#d98a1f'],['priyan','Priya Nair','#c2477f'],['samcooks','Sam Ortiz','#c2473f'],['mayamakes','Maya Chen','#1f9d7a'],['eddyhutt','Eddy Hutt','#3b73f2']];
const STK=['🔥','😂','😍','🙌','✨','💙','🥹','👏','🤯','😎','🌅','🎉'];
const handle=n=>{const norm=s=>(s||'').toLowerCase().trim(); const found=PPL.find(p=>norm(p[1])===norm(n)); return (found?found[0]:norm(n));};
const tg=t=>String(t||'').replace(/[<>&]/g,'').replace(/@(\w+)/g,`<span class='tag'>@$1</span>`);
const MI=[['Block user','M4 4l16 16M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z','User blocked'],['Repost','M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3','Reposted to your profile'],['Add to story','<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>','Added to your story'],['Playback speed','M12 3v4M12 17v4M5 12h4M15 12h4M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z','Speed'],['Duet','<rect x="3" y="6" width="8" height="12" rx="2"/><rect x="13" y="6" width="8" height="12" rx="2"/>','Duet camera opens here'],['Download','M12 3v12M7 10l5 5 5-5M5 21h14','Saving to your device'],['Share to other app','M5 12v7h14v-7M12 15V3M8 7l4-4 4 4','Share sheet opens here'],['Copy link','M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1','Link copied'],['Report','M5 21V4M5 4h12l-2 4 2 4H5','Thanks, we will review this video',1]];
let mV;function openMenu(v,el){mV=v;mE=el;$('#mlist').innerHTML=MI.map((m,i)=>`<button class="mi${m[3]?' bad':''}" data-i="${i}"><svg viewBox="0 0 24 24">${m[1].startsWith('<')?m[1]:`<path d="${m[1]}"/>`}</svg>${m[0]}</button>`).join('');$('#menu').classList.add('open');$$('#mlist .mi').forEach(b=>b.onclick=()=>{const m=MI[b.dataset.i];if(m[0]==='Playback speed'){openSpeedMenu();return}$('#menu').classList.remove('open');if(m[0]==='Repost')doRepost(mV,mE);if(m[0]==='Add to story'){addStory();return}if(m[0]==='Report')setTimeout(()=>openSupport('report'),250);if(m[0]==='Block user')blockUser(mV);if(m[0]==='Copy link'){try{navigator.clipboard.writeText(location.href)}catch(e){}}toast(m[2])})}
function openSpeedMenu(){const cur=(mV&&mV.speed)||1;$('#mlist').innerHTML=`<div class='row' style='margin-bottom:8px'><button class='ib' id='spbk' aria-label='Back'><svg viewBox='0 0 24 24'><path d='M15 5l-7 7 7 7'/></svg></button><h3 style='margin:0'>Playback speed</h3></div>`+[0.5,0.75,1,1.25,1.5,2].map(s=>`<button class='mi' data-sp='${s}'><span style='width:24px;text-align:center;font-weight:700'>${s===1?'1×':s+'×'}</span>${s===cur?'Selected':''}</button>`).join('');$('#spbk').onclick=()=>openMenu(mV,mE);$$('#mlist [data-sp]').forEach(b=>b.onclick=()=>{const sp=+b.dataset.sp;if(mV)mV.speed=sp;const vd=mE&&mE.querySelector('video.vid');if(vd)vd.playbackRate=sp;$('#menu').classList.remove('open');toast('Speed '+(sp===1?'1×':sp+'×'))})}
$('#mscrim').onclick=()=>$('#menu').classList.remove('open');
$('#scrim').onclick=()=>$('#sheet').classList.remove('open');
/* support + tickets (Supabase-backed when available, local fallback otherwise) */
const REPL=['Haha yes!','Send it over 🙌','Love that','Give me five minutes','Perfect, thank you'];
const SI={tk:`<svg viewBox='0 0 24 24'><path d='M3 9V6a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v3a3 3 0 0 0 0 6v3a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-3a3 3 0 0 0 0-6z'/></svg>`,rp:`<svg viewBox='0 0 24 24'><path d='M5 21V4M5 4h12l-2 4 2 4H5'/></svg>`,ch:`<svg viewBox='0 0 24 24'><path d='M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z'/></svg>`};
let SS=[],TF='all',RC='Bug',RS='Minor',STo='',CT=null,USER_TK=[],SUP_TK_OK=false;
const loadTK=()=>KV.get('tickets',[]),saveTK=t=>KV.set('tickets',t),uid=()=>USER&&USER.id||'guest';
function ensureTK(){
 let t=loadTK(),ch=0;
 t.forEach(x=>{if(!Array.isArray(x.msgs)){x.msgs=[];if(x.details)x.msgs.push({by:'user',text:x.details,at:x.created||Date.now()});ch=1}if(!x.user)x.user=uid();if(!x.status)x.status=x.s==='done'?'closed':x.s==='wait'?'open':'open';if(x.s)delete x.s});
 if(ch||t.some(x=>!Array.isArray(x.msgs)))saveTK(t);return t}
function localOpenTKCount(){return ensureTK().filter(t=>t.user===uid()&&t.status==='open').length}
function openTKCount(){return SUP_TK_OK?USER_TK.filter(t=>t.status==='open').length:localOpenTKCount()}
function setSupCardText(n){const el=$('#supCardTxt');if(el)el.textContent=n?`${n} open ticket${n===1?'':'s'} - tap to view`:"Chat with a support agent"}
async function updateSupCard(){
 if(sb&&USER){try{
  const r=await sb.from('support_tickets').select('id,user_id,user_name,subject,status,updated_at,created_at').eq('user_id',USER.id).order('updated_at',{ascending:false}).limit(100);
  if(!r.error){USER_TK=r.data||[];SUP_TK_OK=true;setSupCardText(openTKCount());return USER_TK}
 }catch(e){/* fallback */} SUP_TK_OK=false}
 setSupCardText(openTKCount()); return null}
function renderTickets(){
 const list=$('#stList'); if(!list)return; let t=SUP_TK_OK?USER_TK.slice():ensureTK().filter(x=>x.user===uid()); if(TF==='open')t=t.filter(x=>x.status==='open'); else if(TF==='closed')t=t.filter(x=>x.status==='closed'); t=t.slice().sort((a,b)=>new Date(b.updated_at||b.updated||b.created_at||b.created||0)-new Date(a.updated_at||a.updated||a.created_at||a.created||0));
 list.innerHTML=t.length?t.map(tk=>`<div class="item tk" data-tid="${ESC(tk.id)}"><div><div>${SI.tk}<b>${ESC(tk.subject||'Ticket')}</b><span class="pill ${tk.status==='closed'?'done':'open'}">${tk.status==='open'?'Open':'Closed'}</span></div><small>#${ESC(tk.id)} · ${ESC(tk.updated_at||tk.updated||tk.created_at||tk.created?new Date(tk.updated_at||tk.updated||tk.created_at||tk.created).toLocaleString():'')}</small></div><span class="gt">›</span></div>`).join(''):`<p class="empty" style="padding:16px 0">No tickets yet. Tap “New ticket” to start a chat.</p>`;
}
async function openSupport(){show('support'); setSupCardText(openTKCount()); await updateSupCard(); renderTickets()}
(()=>{const ib=document.querySelector('#inbox button.item'); if(ib) ib.onclick=openSupport; const sc=$('#supCard'); if(sc) sc.onclick=openSupport; $$('#inbox [data-sup], #inbox [data-sup-tickets]').forEach(b=>b.onclick=openSupport)})();
if($('#supBack')) $('#supBack').onclick=()=>show('inbox');
if($('#tTabs')) $('#tTabs').onclick=e=>{const b=e.target.closest('button[data-tf]');if(!b)return;TF=b.dataset.tf;$$('#tTabs button').forEach(x=>x.setAttribute('aria-selected',x===b));renderTickets()};
function showRep(){show('srep')}
function showContact(){show('scontact')}
if($('#newTicket')) $('#newTicket').onclick=()=>{showRep();RC='Bug';RS='Minor';STo='';$$('#repCat .chip').forEach((c,i)=>c.classList.toggle('active',!i));$$('#repSev .chip').forEach((c,i)=>c.classList.toggle('active',!i));const s=$('#tSub'),d=$('#tDesc');if(s)s.value='';if(d)d.value=''};
if($('#rback')) $('#rback').onclick=openSupport; if($('#cback')) $('#cback').onclick=()=>showRep();
if($('#repCat')) $('#repCat').onclick=e=>{const c=e.target.closest('.chip');if(!c)return;RC=c.textContent.trim();$$('#repCat .chip').forEach(x=>x.classList.toggle('active',x===c))};
if($('#repSev')) $('#repSev').onclick=e=>{const c=e.target.closest('.chip');if(!c)return;RS=c.textContent.trim();$$('#repSev .chip').forEach(x=>x.classList.toggle('active',x===c))};
if($('#repNext')) $('#repNext').onclick=()=>{const s=($('#tSub')&&$('#tSub').value||'').trim(); if(!s){toast('Add a subject');return} if($('#ctSub'))$('#ctSub').textContent=s; if($('#ctMeta'))$('#ctMeta').textContent=RC+' · '+RS; showContact()};
async function createTicket(){
 const subject=($('#tSub')&&$('#tSub').value||'').trim(); const details=($('#tDesc')&&$('#tDesc').value||'').trim();
 if(!subject){toast('Add a subject');return}
 if(sb&&USER){try{
  const ins=await sb.from('support_tickets').insert({user_id:USER.id,user_name:ME.name||ME.username||USER.email||'User',subject,status:'open'}).select('id,user_id,user_name,subject,status,updated_at,created_at').single();
  if(ins.error)throw ins.error;
  if(details){await sb.from('ticket_messages').insert({ticket_id:ins.data.id,sender_role:'user',user_id:USER.id,body:details})}
  toast('Ticket created'); await updateSupCard(); await openSupport(); await openThread(ins.data.id); return;
 }catch(e){toast('Could not save ticket to cloud: '+(e&&e.message||e)+'. Using local fallback.'); SUP_TK_OK=false}}
 const now=Date.now(), t={id:'T'+now,user:uid(),subject,cat:RC,sev:RS,status:'open',created:now,updated:now,msgs:details?[{by:'user',text:details,at:now}]:[]};
 const all=ensureTK(); all.push(t); saveTK(all); toast('Ticket created'); updateSupCard(); renderTickets(); show('support'); openThread(t.id);
}
$('#ctSend').onclick=createTicket; $('#ctSave').onclick=createTicket;
async function openThread(id){
 CT=id;
 if(sb&&USER&&SUP_TK_OK){try{
  const tr=await sb.from('support_tickets').select('id,user_id,user_name,subject,status,updated_at,created_at').eq('id',id).single();
  if(tr.error)throw tr.error;
  const mr=await sb.from('ticket_messages').select('id,sender_role,body,created_at').eq('ticket_id',id).order('created_at',{ascending:true});
  const msgs=mr.error?[]:(mr.data||[]);
  const t=tr.data; $('#thSub').textContent=t.subject||'Ticket'; $('#thId').textContent='#'+t.id; $('#thSt').textContent=t.status==='open'?'Open':'Closed'; $('#thSt').className='pill '+(t.status==='closed'?'done':'open');
  const L=$('#tMsgs'); L.innerHTML=msgs.map(m=>`<div class="msg ${m.sender_role==='user'?'me':'them'}"><small style="display:block;opacity:.7;font-size:11px;margin-bottom:2px">${m.sender_role==='admin'?'Support':'You'}${m.created_at?' · '+ESC(new Date(m.created_at).toLocaleString()):''}</small>${ESC(m.body||'')}</div>`).join('')||`<p class="sub" style="padding:12px 0">No messages yet.</p>`; L.scrollTop=L.scrollHeight;
  $('#tReply').style.display=t.status==='open'?'grid':'none'; $('#tClosed').style.display=t.status==='open'?'none':'block';
  show('sthread');
  $('#tSend').onclick=async()=>{const txt=$('#tInput').value.trim(); if(!txt)return; const ins=await sb.from('ticket_messages').insert({ticket_id:id,sender_role:'user',user_id:USER.id,body:txt}); if(ins.error)return toast('Could not send: '+ins.error.message); await sb.from('support_tickets').update({status:'open',updated_at:new Date().toISOString()}).eq('id',id); $('#tInput').value=''; await updateSupCard(); await openThread(id)};
  $('#tReopen').onclick=async()=>{const u=await sb.from('support_tickets').update({status:'open',updated_at:new Date().toISOString()}).eq('id',id); if(u.error)return toast('Could not reopen: '+u.error.message); await updateSupCard(); await openThread(id); toast('Ticket reopened')};
  return;
 }catch(e){SUP_TK_OK=false}}
 const all=ensureTK(), t=all.find(x=>String(x.id)===String(id)); if(!t){toast('Ticket not found');return}
 $('#thSub').textContent=t.subject||'Ticket'; $('#thId').textContent='#'+t.id; $('#thSt').textContent=t.status==='open'?'Open':'Closed'; $('#thSt').className='pill '+(t.status==='closed'?'done':'open');
 const L=$('#tMsgs'); L.innerHTML=(t.msgs||[]).map(m=>`<div class="msg ${m.by==='user'?'me':'them'}"><small style="display:block;opacity:.7;font-size:11px;margin-bottom:2px">${m.by==='admin'?'Support':'You'}${m.at?' · '+ESC(new Date(m.at).toLocaleString()):''}</small>${ESC(m.text||'')}</div>`).join('')||`<p class="sub" style="padding:12px 0">No messages yet.</p>`; L.scrollTop=L.scrollHeight;
 $('#tReply').style.display=t.status==='open'?'grid':'none'; $('#tClosed').style.display=t.status==='open'?'none':'block'; show('sthread');
 $('#tSend').onclick=()=>{const txt=$('#tInput').value.trim(); if(!txt)return; t.msgs=t.msgs||[]; t.msgs.push({by:'user',text:txt,at:Date.now()}); t.updated=Date.now(); saveTK(all); $('#tInput').value=''; updateSupCard(); openThread(id)};
 $('#tReopen').onclick=()=>{t.status='open'; t.updated=Date.now(); saveTK(all); updateSupCard(); renderTickets(); openThread(id); toast('Ticket reopened')};
}
if($('#stList')) $('#stList').onclick=e=>{const it=e.target.closest('[data-tid]'); if(it)openThread(it.dataset.tid)};
if($('#thBack')) $('#thBack').onclick=openSupport;
const FOLL=new Set();
async function doFollow(h,uid){FOLL.add(h);$$(`.fplus[data-h='${h}']`).forEach(b=>{b.classList.add('done');b.innerHTML=`<svg viewBox='0 0 24 24'><path d='M5 12.5l4.5 4.5L19 7.5'/></svg>`;setTimeout(()=>{b.classList.add('gone');setTimeout(()=>b.remove(),260)},900)});toast('Following @'+h); if(sb&&USER&&uid&&uid!==USER.id){try{const r=await sb.from('follows').insert({follower_id:USER.id,following_id:uid}); if(r.error&&r.error.code!=='23505')toast('Follow not saved: '+r.error.message);}catch(e){}} await refreshProfileStatsSafe()}
/* live room v2 */
const GIFTS=[['Rose','🌹',1],['Heart','💙',5],['Coffee','☕',10],['Rocket','🚀',50],['Crown','👑',100],['Galaxy','🌌',299]];
const PACKS=[[70,'$0.99'],[350,'$4.99'],[700,'$9.99'],[1400,'$19.99']];
const LVW=[['Lena Park','#7a4fd6'],['Jo Reyes','#d98a1f'],['Priya Nair','#c2477f'],['Sam Ortiz','#c2473f'],['Alex Kim','#2f8f9d'],['Noor Ali','#8a5ad6'],['Theo Brandt','#3b8f4f'],['Mina Cho','#d2557f'],['Eddy Hutt','#3b73f2']];
const LTX=['this is so good','hiii from Lisbon 👋','how long have you been doing this?','the sky behind you!!','sending love 💙','first time here, following now','what music is this?','omg the colors','can you do a Q&A later?','🔥🔥🔥','good evening everyone','this is my favorite live today'];
const GIC=`<svg viewBox='0 0 24 24'><rect x='3' y='8' width='18' height='4' rx='1'/><path d='M12 8v13M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8M8 8a2.5 2.5 0 1 1 4-2 2.5 2.5 0 1 1 4 2'/></svg>`;
const coin=`<i class='cn'></i>`;
let COINS=40,GSEL=0,lvT=[],lvN=0,LX=null;
function lchat(n,c,t,sys){const L=$('#lchat');if(!L)return;L.insertAdjacentHTML('beforeend',`<div class='lm${sys?' sys':''}'>${av(n,c)}<div><b style='color:${c};color:color-mix(in srgb,${c} 55%,#fff)'>${n}${vb(n)}</b> ${t.replace(/[<>&]/g,'')}</div></div>`);while(L.children.length>7)L.firstChild.remove()}
function lvStop(){lvT.forEach(t=>{clearTimeout(t);clearInterval(t)});lvT=[]}
function lvStart(){lvStop();const pool=()=>LVW.filter(p=>p[0]!==LX[0]),pick=a=>a[Math.floor(Math.random()*a.length)];
 const tick=()=>{if(!$('#room.open')||!$('#lchat'))return lvStop();const p=pick(pool());lchat(p[0],p[1],pick(LTX));lvT.push(setTimeout(tick,1100+Math.random()*1400))};
 lvT.push(setTimeout(tick,700));
 const gt=()=>{if(!$('#room.open'))return lvStop();const p=pick(pool()),g=GIFTS[pick([0,0,1,1,2,3,4])];playGift(g,p[0],p[1]);lchat(p[0],p[1],'sent a '+g[0]+' '+g[1],1);lvT.push(setTimeout(gt,7000+Math.random()*4000))};
 lvT.push(setTimeout(gt,4500));
 lvT.push(setInterval(()=>{lvN=Math.max(50,lvN+Math.round(Math.random()*10-3));const v=$('#vc');if(v)v.textContent=fmt(lvN)},2000))}
function playGift(g,who,col){const f=$('#gfx'),B=$('#gbans');if(!f)return;const big=g[2]>=50;
 B.insertAdjacentHTML('beforeend',`<div class='gban'>${av(who,col,'width:30px;height:30px;font-size:11px')}<div><b>${who}${vb(who)}</b><span>sent ${g[0]}</span></div><span class='gem'>${g[1]}</span></div>`);const bn=B.lastChild;setTimeout(()=>bn.remove(),2800);
 const w=document.createElement('div');w.className='gwrap';w.innerHTML=`${big?`<div class='flash'></div>`:''}<div class='gbig${big?' xl':''}'>${g[1]}</div>`;
 if(big)for(let k=0;k<16;k++){const a=k/16*6.283,d=110+Math.random()*90;w.insertAdjacentHTML('beforeend',`<i class='spk' style='--x:${Math.cos(a)*d}px;--y:${Math.sin(a)*d}px'></i>`)}
 f.appendChild(w);setTimeout(()=>w.remove(),3200)}
function hearts(){const r=$('#room');for(let k=0;k<5;k++)setTimeout(()=>{const h=document.createElement('span');h.className='fh';h.innerHTML=I.heart;h.style.setProperty('--dx',(Math.random()*60-30)+'px');h.style.right=(14+Math.random()*26)+'px';r.appendChild(h);setTimeout(()=>h.remove(),1500)},k*90)}
function viewers(){const rows=LVW.map((p,k)=>`<div class='item' style='cursor:default'>${av(p[0],p[1])}<div class='t'><b>${p[0]}${vb(p[0])}</b><span>${k<3?'Sent '+(3-k)+' gifts':'Watching'}</span></div></div>`).join('');$('#mlist').innerHTML=`<h3 style='margin:0 0 4px'>${fmt(lvN)} watching</h3><p class='sub' style='margin:0 0 6px'>People in this live</p><div style='max-height:50vh;overflow-y:auto'>${rows}</div>`;$('#menu').classList.add('open')}
function buyCoins(msg){$('#mlist').innerHTML=`<h3 style='margin:0 0 4px'>Get coins</h3><p class='sub' style='margin:0 0 12px'>${msg||'Coins let you send gifts to creators.'}</p><div class='packs'>${PACKS.map((p,k)=>`<button class='pack' data-p='${k}'><span>${coin} ${p[0]}</span><b>${p[1]}</b></button>`).join('')}</div><p class='fine'>Preview only. No real payment is made.</p>`;$('#menu').classList.add('open');
 $$('#mlist .pack').forEach(b=>b.onclick=()=>{const p=PACKS[b.dataset.p];COINS+=p[0];$('#menu').classList.remove('open');toast('+'+p[0]+' coins added');if($('#gtray.open'))gtray(true)})}
function gsync(){const b=$('#gsend'),g=GIFTS[GSEL];if(!b)return;b.textContent=!g?'Send':COINS<g[2]?'Get '+(g[2]-COINS)+' more coins':'Send '+g[0]}
function gtray(open){const T=$('#gtray'),R=$('#room');if(!T)return;if(!open){T.classList.remove('open');R.classList.remove('gopen');return}
 T.innerHTML=`<div class='gh'><b>Send a gift</b><button class='coinchip' id='gbuy' aria-label='Get coins'>${coin}<span id='gbal'>${COINS}</span><span class='cp'>+</span></button></div>${COINS<20?`<div class='low'><span>Low balance. Get coins to keep sending gifts.</span><button id='glow'>Get coins</button></div>`:''}<div class='ggrid'>${GIFTS.map((g,k)=>`<button class='gift${k===GSEL?' sel':''}' data-g='${k}'><span class='ge'>${g[1]}</span><b>${g[0]}</b><span class='gp'>${coin} ${g[2]}</span></button>`).join('')}</div><button class='btn' id='gsend' style='width:100%'>Send</button>`;
 T.classList.add('open');R.classList.add('gopen');gsync();
 $$('#gtray .gift').forEach(b=>b.onclick=()=>{GSEL=+b.dataset.g;$$('#gtray .gift').forEach(x=>x.classList.toggle('sel',x===b));gsync()});
 $('#gbuy').onclick=()=>buyCoins('');const gl=$('#glow');if(gl)gl.onclick=()=>buyCoins('');
 $('#gsend').onclick=()=>{const g=GIFTS[GSEL];if(!g){toast('Pick a gift first');return}if(COINS<g[2]){buyCoins('You need '+(g[2]-COINS)+' more coins to send '+g[0]+'.');return}COINS-=g[2];playGift(g,'You','#3b73f2');lchat('You','#3b73f2','sent a '+g[0]+' '+g[1],1);gtray(true)}}
function openLive(i){const x=LIVE[i];LX=x;lvStop();lvN=x[2];GSEL=0;
 const st=[0,1,2].map(k=>av(LVW[k][0],LVW[k][1],'width:26px;height:26px;font-size:10px;border:2px solid #111')).join('');
 $('#room').innerHTML=`${sc(x[4])}<div class='lshade'></div><div class='ltop'><div class='host glass'>${av(x[0],x[3],'width:36px;height:36px;font-size:13px')}<div><b>${x[0]}${vb(x[0])}</b><div class='lsub'><span class='dot'></span>LIVE</div></div></div><button class='vws glass' id='vws' aria-label='People watching'><span class='stack'>${st}</span><b id='vc'>${fmt(lvN)}</b></button><button class='ib glass' id='rx' aria-label='Leave'><svg viewBox='0 0 24 24'><path d='M6 6l12 12M18 6L6 18'/></svg></button></div><div class='gbans' id='gbans'></div><div id='gfx'></div><div class='lchat' id='lchat'></div><div class='lbar'><input id='lin' placeholder='Say something…' aria-label='Add a comment'><button class='ib lsd' id='lsd' aria-label='Send comment'>➤</button><button class='ib glass' id='lgift' aria-label='Send a gift'>${GIC}</button><button class='ib glass' id='lhrt' aria-label='Send hearts'>${I.heart}</button></div><div class='gtray' id='gtray'></div>`;
 $('#rx').onclick=()=>{$('#room').classList.remove('open','gopen');lvStop()};
 $('#vws').onclick=viewers;
 const inp=$('#lin'),sendL=()=>{const t=inp.value.trim();if(!t)return;inp.value='';lchat('You','#3b73f2',t)};
 $('#lsd').onclick=sendL;inp.onkeydown=e=>{if(e.key==='Enter')sendL()};
 $('#lgift').onclick=()=>gtray(true);$('#lhrt').onclick=hearts;
 $('#room').onclick=e=>{if($('#room').classList.contains('gopen')&&!e.target.closest('#gtray,#lgift'))gtray(false)};
 $('#room').classList.add('open');
 lchat('Lena Park','#7a4fd6','good evening everyone');lchat('Jo Reyes','#d98a1f','the sky behind you!!');
 lvStart()}
/* nav + toast */
function show(s){$$('.screen').forEach(x=>x.classList.toggle('show',x.id===s));$$('#nav [data-s]').forEach(b=>b.toggleAttribute('aria-current',b.dataset.s===s));$$('#nav [data-s]').forEach(b=>{if(b.dataset.s===s)b.setAttribute('aria-current','page')});if(s!=='home')$$('.card').forEach(c=>c.classList.add('paused'));else $$('.card.on').forEach(c=>c.classList.remove('paused'));if(s==='profile')refreshProfileStatsSafe()}
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(tt);tt=setTimeout(()=>t.style.display='none',1800)}
function bind(){$$('[data-toast]').forEach(b=>b.onclick=()=>toast(b.dataset.toast))}
$$('[data-s]').forEach(b=>b.onclick=()=>show(b.dataset.s));bind();
homeTab(2);

/* liquid glass lens for tab bars */
function glassLens(root,sel,isOn,attr){
 const L=document.createElement('i');L.className='lens';root.prepend(L);
 const items=()=>[...root.querySelectorAll(sel)];
 let down=false,moved=false,sx=0,supp=false;
 const put=b=>{L.style.left=b.offsetLeft+'px';L.style.width=b.offsetWidth+'px'};
 const sync=()=>{if(down&&moved)return;const b=items().find(isOn);if(b){L.style.opacity=1;put(b)}else L.style.opacity=0};
 root.addEventListener('pointerdown',e=>{if(!e.target.closest(sel))return;down=true;moved=false;sx=e.clientX;L.classList.add('press')});
 root.addEventListener('pointermove',e=>{if(!down)return;if(!moved&&Math.abs(e.clientX-sx)>6){moved=true;L.classList.add('drag')}
  if(moved){const r=root.getBoundingClientRect(),it=items(),w=L.offsetWidth,min=it[0].offsetLeft,max=it[it.length-1].offsetLeft+it[it.length-1].offsetWidth-w;
   L.style.left=Math.max(min,Math.min(max,e.clientX-r.left-w/2))+'px'}});
 const end=e=>{if(!down)return;down=false;L.classList.remove('press','drag');
  if(moved&&e.type==='pointerup'){const c=L.offsetLeft+L.offsetWidth/2;let best=null,bd=1e9;items().forEach(b=>{const d=Math.abs(b.offsetLeft+b.offsetWidth/2-c);if(d<bd){bd=d;best=b}});supp=true;setTimeout(()=>supp=false,60);if(best&&!isOn(best))best.click()}
  moved=false;sync()};
 root.addEventListener('pointerup',end);root.addEventListener('pointercancel',end);
 root.addEventListener('click',e=>{if(supp){e.stopPropagation();e.preventDefault()}},true);
 new MutationObserver(sync).observe(root,{attributes:true,subtree:true,attributeFilter:[attr]});
 addEventListener('resize',sync);addEventListener('load',sync);document.fonts&&document.fonts.ready.then(sync);
 L.style.transition='none';sync();requestAnimationFrame(()=>requestAnimationFrame(()=>L.style.transition=''))}
glassLens($('#nav'),'button[data-s]',b=>b.getAttribute('aria-current')==='page','aria-current');
glassLens($('#htabs'),'button',b=>b.getAttribute('aria-selected')==='true','aria-selected');

/* ===== Features: create, edit profile, search, share, saved settings, tickets ===== */
const closeMenu=()=>$('#menu').classList.remove('open');
/* saved settings + follows */
$$('.sw').forEach(b=>{const k='sw:'+b.getAttribute('aria-label'),s=KV.get(k,null);if(s!==null)b.setAttribute('aria-checked',s);b.addEventListener('click',()=>KV.set(k,b.getAttribute('aria-checked')==='true'))});
KV.get('foll',[]).forEach(x=>FOLL.add(x));
const _df=doFollow;doFollow=function(h){_df(h);KV.set('foll',[...FOLL]);FO.splice(0,FO.length,...FY.filter(v=>FOLL.has(v.h)))};
/* my posts */
let MINE=KV.get('mine',[]);
const me=()=>({n:KV.get('name','Maya Chen'),h:'mayamakes',col:'#1f9d7a'});
/* liked/saved helpers (moved up) */
const _profBase=prof;prof=function(i){
 if(i===0){$('#pgrid').innerHTML=MINE.length?MINE.map(m=>`<div class="th">${m.vid?`<video class="mine-vid" data-scene="${m.s}" src="${encodeURI(m.vid)}#t=0.1" muted playsinline preload="metadata"></video>`:sc(m.s)}<span class="view glass">▶ ${m.l||0}</span><div class="ov">${esc2(m.cap)}</div></div>`).join(''):"<p class='sub'>You haven't posted a video yet.</p>";$$('#pgrid video.mine-vid').forEach(video=>video.addEventListener('error',()=>mediaFallback(video,+video.dataset.scene),{once:true}));return}
 if(i===1){$('#pgrid').innerHTML=repGrid();return}
 if(i===2){$('#pgrid').innerHTML=renderThumbs(KV.get('liked',[]),"Videos you like will show up here.");$$('#pgrid video.mine-vid').forEach(video=>video.addEventListener('error',()=>mediaFallback(video,+video.dataset.scene||0),{once:true}));return}
 if(i===3){$('#pgrid').innerHTML=renderThumbs(KV.get('saved',[]),"Videos you save will show up here.");$$('#pgrid video.mine-vid').forEach(video=>video.addEventListener('error',()=>mediaFallback(video,+video.dataset.scene||0),{once:true}));return}
 $('#pgrid').innerHTML=[['Slow mornings','12 videos'],['No-signal trips','8 videos'],['Dinner for six','5 videos'],['Blue hour','21 videos']].map(c=>`<div class="col">${c[0]}<span>${c[1]}</span></div>`).join('')};
$$('#ptabs button').forEach((b,i)=>b.onclick=()=>{$$('#ptabs button').forEach(x=>x.setAttribute('aria-selected',x===b));prof(i)});
$('#mk').onclick=()=>{let pick=0;
 $('#mlist').innerHTML=`<h3 style='margin:0 0 4px'>New video</h3><p class='sub' style='margin:0 0 10px'>Pick a look, write a caption, add #tags.</p><div class='row' id='cpick' style='gap:8px;margin-bottom:12px'>${[0,1,2,3].map(k=>`<button data-k='${k}' aria-label='Look ${k+1}' style='flex:1;aspect-ratio:9/14;border-radius:12px;overflow:hidden;position:relative;outline:${k?'0':'3px solid #fff'};outline-offset:2px'>${sc(k)}</button>`).join('')}</div><textarea class='fld' id='ccap' maxlength='140' placeholder='What is this moment? #tags'></textarea><button class='btn' id='cpost' style='width:100%;margin-top:10px' disabled>Post</button>`;
 $('#menu').classList.add('open');
 $$('#cpick button').forEach(b=>b.onclick=()=>{pick=+b.dataset.k;$$('#cpick button').forEach(x=>x.style.outline=x===b?'3px solid #fff':'0')});
 $('#ccap').oninput=()=>$('#cpost').disabled=!$('#ccap').value.trim();
 $('#cpost').onclick=()=>{const t=$('#ccap').value.trim(),tg=(t.match(/#\w+/g)||[]).join(' '),cap=t.replace(/#\w+/g,'').replace(/\s+/g,' ').trim()||'New video';
  MINE.unshift({cap,tg,s:pick,t:'Just now'});KV.set('mine',MINE);FY.unshift({...me(),t:'Just now',cap,tg,l:0,c:0,s:pick});
  closeMenu();show('home');homeTab(2);prof(0);toast('Posted to For you')}};
/* edit profile */
let ME={},SUSP=null,ADM={a:[],v:[],tab:0,q:''};
function applyProfile(){const n=KV.get('name','Maya Chen')||'Maya Chen',b=KV.get('bio',null),pn=$('#pname'),avEl=$('#profile .cover .av'),pb=$('#pbio'),pv=$('#pver'),ph=$('#phandle');if(pn)pn.textContent=n;if(ph){const u=(typeof MY_USERNAME!=='undefined'&&MY_USERNAME)||(ME&&ME.username)||'';ph.textContent=u?('@'+u):'@user'}if(pv)pv.innerHTML=(ME&&ME.verified)?vb(n):'';if(avEl&&!avEl.classList.contains('pic'))avEl.textContent=(n.trim()||'U').split(/\s+/).map(w=>w[0]||'').join('').slice(0,2).toUpperCase()||'U';if(pb)pb.textContent=b||'Collecting small moments, good food, and places with no signal. Here for the things that make an ordinary day feel like yours.'}
applyProfile();
$('#editp').onclick=()=>{$('#mlist').innerHTML=`<h3 style='margin:0 0 10px'>Edit profile</h3><label class='lbl'>Name<input class='fld' id='enm' maxlength='30' value='${esc2(KV.get('name','Maya Chen'))}'></label><label class='lbl'>Bio<textarea class='fld' id='ebio' maxlength='160'>${esc2($('#pbio').textContent)}</textarea></label><button class='btn' id='esv' style='width:100%'>Save</button>`;
 $('#menu').classList.add('open');
 $('#esv').onclick=()=>{const n=$('#enm').value.trim()||'Maya Chen';KV.set('name',n);KV.set('bio',$('#ebio').value.trim());applyProfile();closeMenu();toast('Profile updated')}};
/* search */
let PEOPLE=[...new Map([...FY,...FO].map(v=>[v.h,[v.n,v.h,v.col]])).values()];
function realDiscover(){const g=$('#dgrid');if(!g)return;const l=FY.filter(v=>v.vid);g.innerHTML=l.length?l.slice(0,24).map((m,i)=>`<button class='th' data-dv='${i}' style='text-align:left'><video src="${esc2(m.vid)}#t=0.1" muted playsinline preload="metadata"></video><span class='view glass'>❤ ${fmt(m.l||0)}</span><div class='ov'>${esc2(m.cap||'')}</div></button>`).join(''):"<p class='sub'>No videos yet.</p>";$$('#dgrid [data-dv]').forEach(b=>b.onclick=()=>openPop(l[b.dataset.dv]));const T={};FY.forEach(v=>(v.tg||'').split(' ').filter(Boolean).forEach(t=>T[t]=(T[t]||0)+1));const top=Object.entries(T).sort((a,b)=>b[1]-a[1]).slice(0,5);$('#trend').innerHTML=top.length?top.map((t,i)=>`<div class="tr"><div><b>${i+1}. ${esc2(t[0])}</b></div><span>${t[1]} video${t[1]>1?'s':''}</span></div>`).join(''):"<p class='sub'>Hashtags will appear here.</p>"}
function rebuildPeople(){realDiscover();PEOPLE=[...new Map([...FY,...FO].map(v=>[v.h,[v.n,v.h,v.col]])).values()]; if(typeof renderSearch==='function')renderSearch()}
if($('#trend')&&$('#trend').previousElementSibling && !$('#ppl')) $('#trend').previousElementSibling.insertAdjacentHTML('beforebegin',"<div id='ppl'></div>");
const si=$('#discover .search input');
function renderSearch(){ if(!si)return; const q=si.value.trim().toLowerCase().replace(/^[#@]/,''); let any=0;
 $$('#trend .tr').forEach(t=>{const m=!q||t.textContent.toLowerCase().includes(q);t.style.display=m?'':'none';if(m)any=1});
 const P=q?PEOPLE.filter(p=>((p[1]||'')+' '+(p[0]||'')).toLowerCase().includes(q)):[];
 const ppl=$('#ppl'); if(!ppl)return;
 ppl.innerHTML=(P.length?'<h3>People</h3>'+P.map(p=>`<div class='item ppl' data-h='${esc2(p[0]||'')}' data-n='${esc2(p[1]||'')}' style='cursor:pointer'>${av(p[1],p[2])}<div class='t'><b>${esc2(p[1]||'')}${vb(p[1])}</b><span>@${esc2(p[0]||'')}</span></div></div>`).join(''):'')+(q&&!any&&!P.length?`<p class='sub'>No results for "${esc2(q)}".</p>`:'');
 $$('#ppl .ppl').forEach(el=>el.onclick=()=>openUserProfile({username:el.dataset.h,display_name:el.dataset.n}));
}
if(si){ si.oninput=renderSearch; si.addEventListener('input',renderSearch); }
$$('#chips .chip').forEach((b,i)=>b.addEventListener('click',()=>realDiscover()));
/* share, inbox badge */
document.addEventListener('click',e=>{const b=e.target.closest('[data-k=sh]');if(!b)return;e.stopPropagation();const d={title:'Visual',text:'Check this out on Visual',url:location.href};
 if(navigator.share)navigator.share(d).catch(()=>{});else{try{navigator.clipboard.writeText(d.url);toast('Link copied')}catch(err){toast('Copy the link from the address bar')}}},true);
$('#nav [data-s=inbox]').addEventListener('click',()=>{const n=$('#nav .nb');if(n)n.remove()});


/* ===== Supabase auth + cloud data ===== */
let sb=null;
try{
  const CLOUD_CHECK=!!(window.VISUAL_CONFIG&&window.supabase&&!/YOUR/.test(window.VISUAL_CONFIG.SUPABASE_URL||''));
  if(CLOUD_CHECK){sb=supabase.createClient(window.VISUAL_CONFIG.SUPABASE_URL,window.VISUAL_CONFIG.SUPABASE_ANON_KEY);console.log('Supabase client created');}
  else{console.warn('CLOUD_CHECK failed:',{hasConfig:!!window.VISUAL_CONFIG,hasSupabase:!!window.supabase,url:window.VISUAL_CONFIG?window.VISUAL_CONFIG.SUPABASE_URL:null});}
}catch(e){console.error('Supabase init error',e);}
const CLOUD=!!sb;
console.log('App startup:',{CLOUD,hasConfig:!!window.VISUAL_CONFIG,supabaseUrl:window.VISUAL_CONFIG?.SUPABASE_URL,hasSupabaseLib:!!window.supabase});

// If Supabase is not connected, skip auth screen and go straight to home (guest mode)
if(!CLOUD){
  $('#aerr').textContent='Supabase not connected. Browse as guest below. Login requires Supabase config.';
  $('#aerr').style.color='#ff7a8a';
  homeTab(2);
} else {
  // Supabase is connected - check for existing session
  sb.auth.getSession().then(async({data})=>{
   try{
    if(data&&data.session&&data.session.user){ if(!USER||USER.id!==data.session.user.id) await onSignedIn(data.session.user); else { closeAuthUI(); await loadPublicFeed().catch(()=>{}); } }
    else { KV.set('name','');KV.set('bio','');resetProfileUI(); await loadPublicFeed().catch(()=>{}); if(!USER) showAuth() }
   }catch(e){console.error('getSession',e); await loadPublicFeed().catch(()=>{}); if(!USER) showAuth()}
  }).catch(async(e)=>{ console.error('getSession fail',e); await loadPublicFeed().catch(()=>{}); if(!USER) showAuth() });
}
const showAuth=()=>{$('#auth').classList.add('open');requestAnimationFrame(()=>dispatchEvent(new Event('resize')));$('#aerr').textContent=CLOUD?'':(!window.VISUAL_CONFIG?'Accounts are off: config.js did not load. You can still look around as a guest.':'Accounts are off: could not load the Supabase library. Check your internet connection or ad blocker, or look around as a guest.')};
const hideAuth=()=>{const a=$('#auth'); if(a)a.classList.remove('open')};
const closeAuthUI=hideAuth;
const ago=d=>{const m=(Date.now()-new Date(d))/6e4;return m<1?'Just now':m<60?Math.floor(m)+' min ago':m<1440?Math.floor(m/60)+' h ago':Math.floor(m/1440)+' d ago'};
glassLens($('#atabs'),'button',b=>b.getAttribute('aria-selected')==='true','aria-selected');
$$('#atabs button').forEach((b,i)=>b.onclick=()=>{AMODE=i;$$('#atabs button').forEach(x=>x.setAttribute('aria-selected',x===b));$('#anw').hidden=!i;$('#ago').textContent=i?'Create account':'Log in';$('#asub').textContent=i?'Join Visual. It takes a minute.':'Welcome back. Log in to continue.';$('#apw').autocomplete=i?'new-password':'current-password';$('#aerr').textContent=''});
$('#aguest').onclick=()=>{hideAuth();homeTab(2);toast('Guest mode - browse without account');};
async function submitAuth(){if(!CLOUD){const err=$('#aerr'); if(err){err.textContent='Supabase not connected. Check console (F12) for details.';err.style.color='#ff7a8a';}return}const email=$('#aem').value.trim(),password=$('#apw').value,err=$('#aerr'),btn=$('#ago');err.className='';err.textContent='';if(!email||password.length<6){err.textContent='Enter your email and a password of at least 6 characters.';return}btn.disabled=true;try{console.log('Auth attempt:',AMODE?'signup':'login',email);const r=AMODE?await sb.auth.signUp({email,password,options:{data:{display_name:($('#aname')?$('#aname').value.trim():'')||email.split('@')[0]}}}):await sb.auth.signInWithPassword({email,password});console.log('Auth result',{error:r.error,hasSession:!!r.data?.session,hasUser:!!r.data?.user});if(r.error){err.textContent=r.error.message;err.style.color='#ff7a8a';console.error('Auth error',r.error);return}if(r.data&&r.data.session&&r.data.user){console.log('Session established, calling onSignedIn');await onSignedIn(r.data.user); return}if(AMODE&&!r.data.session){err.className='ok';err.textContent='Check your email to confirm your account, then log in. Or disable "Confirm email" in Supabase Authentication settings.';err.style.color='#6ee7a8';console.log('Signup succeeded but no session - email confirmation likely enabled');}else if(!AMODE){err.textContent='Login succeeded but no session. Disable "Confirm email" in Supabase Authentication → Settings, or check your email for a confirmation link.';err.style.color='#ff7a8a';console.log('Login succeeded but no session - email confirmation likely enabled');}}catch(e){const msg=(e&&e.message)||String(e);err.textContent=/fetch|network|load failed/i.test(msg)?'Cannot reach the server. Check your internet connection (or VPN/ad blocker) and try again.':'Auth error: '+msg;err.style.color='#ff7a8a';console.error('Auth exception',e)}finally{btn.disabled=false}}
$('#ago').onclick=submitAuth;$('#apw').onkeydown=e=>{if(e.key==='Enter')submitAuth()};
async function fetchVideoRows(){
 const r0=await sb.from('videos').select('*').order('created_at',{ascending:false}).limit(60);
 if(r0.error)return{rows:null,error:r0.error};
 const rows=(r0.data||[]).filter(x=>!x.status||x.status==='published').slice(0,40);
 const ids=[...new Set(rows.map(x=>x.user_id).filter(Boolean))],pmap=new Map();
 if(ids.length){
  let p=await sb.from('profiles').select('id,username,display_name,avatar_url,verified').in('id',ids);
  if(p.error)p=await sb.from('profiles').select('id,username,display_name,avatar_url').in('id',ids);
  if(p.error)p=await sb.from('profiles').select('id,username,display_name').in('id',ids);
  if(p.error)console.warn('profiles lookup failed',p.error);
  (p.data||[]).forEach(x=>pmap.set(x.id,x));
 }
 rows.forEach(x=>{x.profiles=pmap.get(x.user_id)||null});
 return{rows,error:null};
}
async function loadPublicFeed(){
 if(!sb){try{homeTab(2)}catch(e){}; return}
 if(!FY.length)feedLoad();
 try{
  let {rows,error}=await fetchVideoRows();
  if(error){console.error(error); if(!FY.length){feedLoad(navigator.onLine?'Still loading…':'Waiting for connection…');scheduleFeedRetry();return} toast('Could not load feed: '+(error.message||error)); try{homeTab(2)}catch(_){}; return}
  const sc2=p2=>{const m=/^scene\/(\d)$/.exec((p2&&p2.storage_path)||'');return m?+m[1]:[...String((p2&&p2.id)||'0')].reduce((x,c)=>x+c.charCodeAt(0),0)%4},sp=p2=>{const caption=(p2&&p2.caption)||'',tg=(caption.match(/#\w+/g)||[]).join(' ');return{cap:caption.replace(/#\w+/g,'').replace(/\s+/g,' ').trim()||'New video',tg}};
  const pub=(rows||[]).filter(r=>!r.status||r.status==='published');
  const items=pub.map(r=>{const pf=r.profiles||{},avatar=pf.avatar_url?imgUrl(pf.avatar_url):'';if(avatar){PROFILE_PICS.set(pf.display_name,avatar);PROFILE_PICS.set(pf.username,avatar)}if(pf.verified&&pf.display_name&&!VER.includes(pf.display_name))VER.push(pf.display_name);return{id:r.id,user_id:r.user_id,n:pf.display_name||'Visual user',h:pf.username||'user',t:r.created_at?ago(r.created_at):'',...sp(r),pr:isPr?isPr(r):!!r.promoted,l:+r.likes_count||0,c:+r.comments_count||0,sv:+r.saves_count||0,sh:+r.shares_count||0,col:'#3b73f2',s:sc2(r),avatar,vid:/^scene\//.test(r.storage_path||'')?'':(typeof vidUrl==='function'?vidUrl(r.storage_path):'')}});
  for(let i=items.length;i--;)if(!items[i].vid)items.splice(i,1);items.sort((a,b)=>Number(a.pr)-Number(b.pr));
   FY.splice(0,FY.length,...items);FO.splice(0,FO.length,...items.filter(v=>FOLL.has(v.h)));
  if(typeof rebuildPeople==='function')rebuildPeople();
  const active=$$('#htabs button').findIndex(b=>b.getAttribute('aria-selected')==='true'); homeTab(active>=0?active:2);
 }catch(e){console.error(e); if(!FY.length){feedLoad(navigator.onLine?'Still loading…':'Waiting for connection…');scheduleFeedRetry();return} toast('Could not load feed'); try{homeTab(2)}catch(_){}}
}

async function onSignedIn(u){
 if(!u) return;
 if(USER&&USER.id===u.id){closeAuthUI(); return}
 if(_signingIn===u.id) return;
 _signingIn=u.id;
 try{
  USER=u;closeAuthUI();resetProfileUI();
  let {data:pr,error:profileError}=await sb.from('profiles').select('username,display_name,bio,is_admin,avatar_url,banner_url,verified,banned,suspended_until,admin_role,admin_perms').eq('id',u.id).maybeSingle();
  if(profileError){console.warn('full profile select failed, retrying',profileError);let r=await sb.from('profiles').select('username,display_name,bio,is_admin,avatar_url,banner_url').eq('id',u.id).maybeSingle();if(r.error)r=await sb.from('profiles').select('username,display_name,bio').eq('id',u.id).maybeSingle();pr=r.data;profileError=r.error}
  if(!pr&&!profileError){try{const nm=(u.user_metadata&&u.user_metadata.display_name)||(u.email||'user').split('@')[0];await sb.from('profiles').upsert({id:u.id,username:(u.email||'user').split('@')[0],display_name:nm});pr={display_name:nm,username:(u.email||'user').split('@')[0]}}catch(e){console.warn('profile create failed',e)}}
  if(profileError)console.warn('profile load',profileError);
  const p=pr||{},displayName=p.display_name||u.user_metadata&&u.user_metadata.display_name||u.email&&u.email.split('@')[0]||'User';
  KV.set('name',displayName);KV.set('bio',p.bio||'');MY_USERNAME=p.username||'';ME=p;SUSP=ME.suspended_until&&new Date(ME.suspended_until)>new Date()?ME.suspended_until:null;
  if(ME.banned){await sb.auth.signOut();USER=null;ME={};resetProfileUI();showAuth();$('#aerr').textContent='This account is banned.';return}
  LIVE[0][0]=displayName;applyProfile();paintImgs(p);$('#adminBtn').hidden=!p.is_admin;
  if(SUSP)toast('Account suspended until '+dte(SUSP));
  const {data:mine,error:mineError}=await sb.from('videos').select('*').eq('user_id',u.id).order('created_at',{ascending:false}).limit(1000);
  if(mineError)console.warn('mine load',mineError);
  const sc2=p2=>{const m=/^scene\/(\d)$/.exec(p2.storage_path||'');return m?+m[1]:[...p2.id].reduce((x,c)=>x+c.charCodeAt(0),0)%4},sp=p2=>{const caption=p2.caption||'',tg=(caption.match(/#\w+/g)||[]).join(' ');return{cap:caption.replace(/#\w+/g,'').replace(/\s+/g,' ').trim()||'New video',tg}};
  MINE=(mine||[]).filter(x=>!/^scene\//.test(x.storage_path||'')).map(x=>({...sp(x),id:x.id,storage_path:x.storage_path,s:sc2(x),t:ago(x.created_at),l:+x.likes_count||0,c:+x.comments_count||0,sv:+x.saves_count||0,sh:+x.shares_count||0,vid:/^scene\//.test(x.storage_path||'')?'':vidUrl(x.storage_path)}));
  let {rows,error:feedError}=await fetchVideoRows();
  if(feedError){console.error(feedError);toast('Could not load videos: '+(feedError.message||feedError))}
  if(!feedError){
   const pub=(rows||[]).filter(r=>!r.status||r.status==='published');
   const items=pub.map(r=>{const pf=r.profiles||{},avatar=pf&&pf.avatar_url?imgUrl(pf.avatar_url):'';if(avatar){PROFILE_PICS.set(pf.display_name,avatar);PROFILE_PICS.set(pf.username,avatar)}if(pf&&pf.verified&&pf.display_name&&!VER.includes(pf.display_name))VER.push(pf.display_name);return{id:r.id,user_id:r.user_id,n:(pf&&pf.display_name)||'Visual user',h:(pf&&pf.username)||'user',t:r.created_at?ago(r.created_at):'',...sp(r),pr:(typeof isPr==='function'?isPr(r):!!r.promoted),l:+r.likes_count||0,c:+r.comments_count||0,sv:+r.saves_count||0,sh:+r.shares_count||0,col:r.user_id===u.id?'#1f9d7a':'#7a4fd6',s:sc2(r),avatar,vid:/^scene\//.test(r.storage_path||'')?'':(typeof vidUrl==='function'?vidUrl(r.storage_path):'')}});
   for(let i=items.length;i--;)if(!items[i].vid)items.splice(i,1);items.sort((a,b)=>Number(a.pr)-Number(b.pr));
   FY.splice(0,FY.length,...items);FO.splice(0,FO.length,...items.filter(v=>FOLL.has(v.h)));
  }
  try{const fr=await sb.from('follows').select('following_id,profiles:following_id(username)').eq('follower_id',u.id); if(!fr.error){FOLL.clear(); (fr.data||[]).forEach(r=>{const h=r.profiles&&r.profiles.username; if(h)FOLL.add(h)});} FO.splice(0,FO.length,...FY.filter(v=>FOLL.has(v.h)));}catch(e){}
  await loadMyReactionsSafe().catch(()=>{}); await refreshProfileStatsSafe().catch(()=>{}); await updateSupCard().catch(()=>{});
  applyBlocks();homeTab($$('#htabs button').findIndex(b=>b.getAttribute('aria-selected')==='true')>=0?$$('#htabs button').findIndex(b=>b.getAttribute('aria-selected')==='true'):2);prof(0);if(typeof rebuildPeople==='function')rebuildPeople();
 }catch(e){console.error('onSignedIn failed',e); toast('Signed in, but some data failed to load. Pull to refresh/reload.')}
 finally{_signingIn=null}
}
if(sb){
 sb.auth.onAuthStateChange(async(ev,s)=>{
  try{
   if(s&&s.user){ if(!USER||USER.id!==s.user.id) await onSignedIn(s.user); else closeAuthUI(); }
   else if(ev==='SIGNED_OUT'){ USER=null;ME={};SUSP=null;KV.set('name','');KV.set('bio','');resetProfileUI();await loadPublicFeed().catch(()=>{});showAuth(); }
  }catch(e){console.error('auth state',e)}
 });
 sb.auth.getSession().then(async({data})=>{
  try{
   if(data&&data.session&&data.session.user){ if(!USER||USER.id!==data.session.user.id) await onSignedIn(data.session.user); else { closeAuthUI(); await loadPublicFeed().catch(()=>{}); } }
   else { KV.set('name','');KV.set('bio','');resetProfileUI(); await loadPublicFeed().catch(()=>{}); if(!USER) showAuth() }
  }catch(e){console.error('getSession',e); await loadPublicFeed().catch(()=>{}); if(!USER) showAuth()}
 }).catch(async(e)=>{ console.error('getSession fail',e); await loadPublicFeed().catch(()=>{}); if(!USER) showAuth() });
}else { homeTab(2); showAuth(); }
/* cloud writes */
const _mk2=$('#mk').onclick;$('#mk').onclick=()=>{_mk2();const b=$('#cpost'),o=b.onclick;b.onclick=()=>{o();if(!USER)return;const p=MINE[0];
 sb.from('videos').insert({user_id:USER.id,storage_path:'scene/'+p.s,caption:(p.cap+' '+p.tg).trim()}).then(r=>{if(r.error)toast('Could not save post: '+r.error.message)})}};
const _ep=$('#editp').onclick;$('#editp').onclick=()=>{_ep();const s=$('#esv'),o=s.onclick;s.onclick=()=>{o();if(USER)sb.from('profiles').update({display_name:KV.get('name',''),bio:KV.get('bio','')}).eq('id',USER.id)}};
const lo=[...$$('#settings .srow')].find(b=>/Log out/.test(b.textContent));
if(lo){lo.removeAttribute('data-toast');lo.onclick=async()=>{if(sb)await sb.auth.signOut();USER=null;ME={};SUSP=null;KV.set('name','');KV.set('bio','');resetProfileUI();show('home');showAuth()}}

/* helpers */
const imgUrl=p=>!p?'':/^http/.test(p)?p:sb.storage.from('arc-profiles').getPublicUrl(p).data.publicUrl;
const vidUrl=p=>{p=String(p||'').trim();if(!p)return'';if(/^https?:/i.test(p))return p;return sb.storage.from('arc-videos').getPublicUrl(p.replace(/^\/+/,'')).data.publicUrl};
const sheetOpen=h=>{$('#mlist').innerHTML=h;$('#menu').classList.add('open')};
/* profile picture + banner */
function resetProfileUI(){const c=$('#profile .cover'),a=$('#profile .cover .av'),pn=$('#pname'),pb=$('#pbio'),pv=$('#pver');if(c)c.style.background='';if(a){a.style.background='';a.classList.remove('pic');a.textContent=''}if(pn)pn.textContent='';if(pv)pv.innerHTML='';if(pb)pb.textContent='Collecting small moments, good food, and places with no signal. Here for the things that make an ordinary day feel like yours.';PROFILE_PICS.clear();MINE=[];$('#adminBtn').hidden=true}
function paintImgs(pr){const c=$('#profile .cover'),a=$('#profile .cover .av'),p=pr||{};
 if(c)c.style.background=p.banner_url?`center/cover url("${imgUrl(p.banner_url)}")`:'';
 if(a){if(p.avatar_url){const avatar=imgUrl(p.avatar_url);a.style.background=`center/cover url("${avatar}")`;a.classList.add('pic');a.textContent='';PROFILE_PICS.set(KV.get('name',''),avatar);PROFILE_PICS.set('You',avatar);if(MY_USERNAME)PROFILE_PICS.set(MY_USERNAME,avatar);FY.concat(FO).forEach(v=>{if(USER&&v.user_id===USER.id)v.avatar=avatar});renderLiveGrid();const tab=$('#htabs button[aria-selected=true]');if(tab)homeTab($$('#htabs button').indexOf(tab))}else{a.style.background='';a.classList.remove('pic');a.textContent=(KV.get('name','User')||'U').trim().split(/\s+/).map(w=>w[0]||'').join('').slice(0,2).toUpperCase()||'U'}}}
function pickImg(w,h){return new Promise(res=>{const i=document.createElement('input');i.type='file';i.accept='image/*';i.onchange=()=>{const f=i.files[0];if(!f)return res(null);const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=w;c.height=h;const s=Math.max(w/im.width,h/im.height),dw=im.width*s,dh=im.height*s;c.getContext('2d').drawImage(im,(w-dw)/2,(h-dh)/2,dw,dh);c.toBlob(res,'image/jpeg',.88)};im.onerror=()=>res(null);im.src=URL.createObjectURL(f)};i.click()})}
async function setPic(kind){if(!USER)return toast('Log in first');const av=kind==='avatar',b=await pickImg(av?512:1500,av?512:500);if(!b)return;toast('Uploading…');
 const path=`${USER.id}/${kind}/${crypto.randomUUID()}.jpg`,up=await sb.storage.from('arc-profiles').upload(path,b,{contentType:'image/jpeg'});
 if(up.error)return toast('Upload failed: '+up.error.message);
 const r=await sb.from('profiles').update({[kind+'_url']:path}).eq('id',USER.id);if(r.error)return toast('Could not save: '+r.error.message);
 paintImgs({[kind+'_url']:path});toast(av?'Profile picture updated':'Banner updated')}
const _ep2=$('#editp').onclick;$('#editp').onclick=()=>{_ep2();$('#esv').insertAdjacentHTML('beforebegin',"<div class='row' style='margin:0 0 12px'><button class='btn o' id='epic' style='flex:1'>Change photo</button><button class='btn o' id='eban' style='flex:1'>Change banner</button></div>");$('#epic').onclick=()=>setPic('avatar');$('#eban').onclick=()=>setPic('banner')};
/* blocked users */
const blocked=()=>KV.get('blocked',[]);
function applyBlocks(){const b=blocked();for(let i=FY.length;i--;)if(b.includes(FY[i].h))FY.splice(i,1)}
function blockUser(v){if(!v||!v.h)return;const b=blocked();if(!b.includes(v.h))KV.set('blocked',b.concat(v.h));applyBlocks();homeTab(2)}
/* settings */
const SR=t=>[...$$('#settings .srow')].find(b=>b.textContent.trim().startsWith(t));
const setRow=(t,f)=>{const r=SR(t);if(r){r.removeAttribute('data-toast');r.onclick=f}};
setRow('Account info',async()=>{if(!USER)return toast('Log in to see account info');
 const {data:p}=await sb.from('profiles').select('username,display_name,created_at').eq('id',USER.id).maybeSingle();const q=p||{};
 sheetOpen(`<h3 style='margin:0 0 10px'>Account info</h3><p class='sub' style='margin:0 0 4px'>Email</p><b>${ESC(USER.email)}</b><p class='sub' style='margin:10px 0 4px'>Member since</p><b>${ESC(new Date(q.created_at||USER.created_at).toLocaleDateString())}</b><label class='lbl' style='margin-top:12px'>Username<input class='fld' id='aiu' maxlength='24' value='${ESC(q.username||'')}'></label><button class='btn' id='aius' style='width:100%;margin-bottom:12px'>Save username</button><label class='lbl'>New password<input class='fld' id='aip' type='password' autocomplete='new-password' placeholder='At least 6 characters'></label><button class='btn o' id='aips' style='width:100%'>Change password</button>`);
 $('#aius').onclick=async()=>{const u=$('#aiu').value.trim().toLowerCase().replace(/[^a-z0-9_.]/g,'');if(u.length<3)return toast('Username needs 3+ letters or numbers');const r=await sb.from('profiles').update({username:u}).eq('id',USER.id); if(r.error)return toast('Could not save: '+r.error.message); MY_USERNAME=u; ME.username=u; applyProfile(); toast('Username updated')};
 $('#aips').onclick=async()=>{const pw=$('#aip').value;if(pw.length<6)return toast('Password needs 6+ characters');const r=await sb.auth.updateUser({password:pw});toast(r.error?r.error.message:'Password changed');if(!r.error)$('#aip').value=''}});
setRow('Community guidelines',()=>sheetOpen(`<h3 style='margin:0 0 10px'>Community guidelines</h3><div style='max-height:55vh;overflow-y:auto;line-height:1.5'><p><b>Be kind.</b> No harassment, hate or bullying.</p><p><b>Keep it safe.</b> No violence, dangerous acts or content that exploits minors.</p><p><b>Be honest.</b> No scams, spam or impersonation.</p><p><b>Respect creators.</b> Only post videos you made or have permission to use.</p><p><b>Protect privacy.</b> Do not share other people's personal details.</p><p style='color:var(--mute)'>Report anything that breaks these rules from a video's menu. Repeat violations can lead to a ban.</p></div>`));
const LG=['English','Español','Français','Deutsch','Português'];
const setLang=()=>{const r=SR('Language');if(r)r.querySelector('.ch').textContent=KV.get('lang','English')+' ›'};
setRow('Language',()=>{sheetOpen(`<h3 style='margin:0 0 10px'>Language</h3>${LG.map(l=>`<button class='srow' data-l='${l}'>${l}<span class='ch'>${KV.get('lang','English')===l?'✓':''}</span></button>`).join('')}`);$$('#mlist [data-l]').forEach(b=>b.onclick=()=>{KV.set('lang',b.dataset.l);setLang();closeMenu();toast('Language set to '+b.dataset.l)})});setLang();
setRow('Blocked users',function f(){const b=blocked();sheetOpen(`<h3 style='margin:0 0 10px'>Blocked users</h3>${b.length?b.map(h=>`<div class='srow'>@${ESC(h)}<button class='btn o' data-u='${ESC(h)}' style='padding:7px 14px'>Unblock</button></div>`).join(''):"<p class='sub'>You have not blocked anyone. Block someone from a video's menu (long-press the video).</p>"}`);$$('#mlist [data-u]').forEach(x=>x.onclick=()=>{KV.set('blocked',blocked().filter(h=>h!==x.dataset.u));toast('Unblocked');f()})});
/* admin */
const isPr=p=>p.promoted&&(!p.promoted_until||new Date(p.promoted_until)>new Date());
const can=k=>ME.admin_role==='owner'||(ME.admin_role==='admin'&&k!=='admins')||!!(ME.admin_perms||{})[k];
const dte=d=>new Date(d).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'});
const hl=p=>p.banned?['Banned','#c2473f']:p.suspended_until&&new Date(p.suspended_until)>new Date()?['Suspended','#d98a1f']:p.strikes>=2?['At risk','#d98a1f']:p.strikes===1?['Warning','#b8a21f']:['Good standing','#1f9d7a'];
const atag=(t,c)=>`<span class='mini' style='padding:2px 8px;border:0;font-size:11px;background:${c};margin-left:6px'>${t}</span>`;
const pic=(p,z)=>{const n=p.display_name||p.username||'User',u=p.avatar_url?imgUrl(p.avatar_url):'';return `<span class='av${u?' pic':''}' style='width:${z}px;height:${z}px;font-size:${z/3}px;border:0;background:${u?`center/cover url("${ESC(u)}")`:'#3b73f2'}'>${ESC(n.split(' ').map(w=>w[0]||'').join('').slice(0,2).toUpperCase())}</span>`};
async function loadAdmin(){
 if(!ME||!ME.is_admin){const ab=$('#adminBtn'); if(ab)ab.hidden=true; toast('Admin access only'); show('home'); return}
 const box=$('#abody');if(box)box.innerHTML="<p class='sub'>Loading...</p>";
 let a={data:[],error:null},v={data:[],error:null},tk={data:[],error:null};
 if(sb){try{[a,v,tk]=await Promise.all([
  sb.from('profiles').select('id,username,display_name,avatar_url,created_at,is_admin,verified,banned,coins,suspended_until,strikes,admin_role,admin_perms,status_note').order('created_at',{ascending:false}),
  sb.from('videos').select('id,user_id,caption,storage_path,status,created_at,promoted,promoted_until,likes_count,comments_count,saves_count,shares_count').order('created_at',{ascending:false}),
  sb.from('support_tickets').select('id,user_id,user_name,subject,status,updated_at,created_at').order('updated_at',{ascending:false}).limit(200)
 ])}catch(e){a={data:[],error:{message:e.message||String(e)}}}} 
 const err=(a&&a.error)||(v&&v.error)?((a.error&&a.error.message)||(v.error&&v.error.message)||'Could not load cloud data'):'';
 ADM={a:(a&&a.data)||[],v:(v&&v.data)||[],tk:(tk&&tk.data)||[],tkErr:(tk&&tk.error)?(tk.error.message||String(tk.error)):'',tab:0,q:'',err};
 if(box)box.innerHTML="<div class='ad-stats' id='astats'></div><div class='ad-tabs' id='atb'><button data-tab='0'>Accounts</button><button data-tab='1'>Videos</button><button data-tab='2'>Tickets</button></div><input class='fld' id='aq' placeholder='Search' aria-label='Search' style='margin-bottom:12px'><div id='alist'></div>";renderAdmin()}
async function renderAdmin(){const{a=[],v=[],tk=[],tab=0,q='',err='',tkErr=''}=ADM||{},pm=new Map(a.map(p=>[p.id,p])),k=String(q).toLowerCase();
 const stats=$('#astats'),tabs=$$('#atb button'),list=$('#alist'); if(stats)stats.innerHTML=[[a.length,'Accounts'],[v.length,'Videos'],[tk.filter(t=>t.status==='open').length,'Open tickets'],[a.filter(p=>p.banned).length,'Banned'],[v.filter(x=>x.status!=='published').length,'Hidden videos']].map(s=>`<div class='ad-s'><b>${s[0]}</b><span>${s[1]}</span></div>`).join('');
 tabs.forEach(b=>b.setAttribute('aria-selected',+b.dataset.tab===tab)); if(!list)return;
 if(tab===2){
  if(tkErr){list.innerHTML=`<p class='sub'>Could not load tickets: ${ESC(tkErr)}. Run the updated supabase-setup.sql in Supabase SQL editor, then reload.</p>`;return}
  const items=tk.filter(t=>!k||[t.id,t.subject,t.user_name,t.user_id,t.status].join(' ').toLowerCase().includes(k));
  list.innerHTML=items.length?items.map(t=>`<div class='ad-c'><div class='t'><b>${ESC(t.subject||'(no subject)')}</b><div style='color:var(--mute);font-size:13px;margin-top:4px'>${ESC(t.user_name||'User')} · #${ESC(t.id)} · ${ESC(t.updated_at?new Date(t.updated_at).toLocaleString():'')}</div><div style='margin-top:6px'>${atag(t.status==='open'?'Open':'Closed',t.status==='open'?'#d98a1f':'#1f9d7a')}</div><div class='acts'><button class='mini' data-atk='${t.id}'>Open ticket</button><button class='mini' data-atog='${t.id}'>${t.status==='open'?'Close':'Reopen'}</button></div></div></div>`).join(''):`<p class='sub'>No tickets found.</p>`;
  return;
 }
 if(err){list.innerHTML=`<p class='sub'>Cloud accounts/videos unavailable: ${ESC(err)}</p>`;return}
 list.innerHTML=(tab===1?v.filter(x=>((x.caption||'')+((pm.get(x.user_id)||{}).username||'')).toLowerCase().includes(k)).map(x=>{const o=pm.get(x.user_id)||{},real=!/^scene\//.test(x.storage_path||'');
  return `<div class='ad-c'>${real?`<video src='${ESC(vidUrl(x.storage_path))}#t=0.1' preload='metadata' controls muted playsinline style='width:96px;height:140px;object-fit:contain;border-radius:12px;background:#000;flex:none'></video>`:`<div style='width:96px;height:140px;border-radius:12px;background:#1b1f29;flex:none;display:grid;place-items:center;color:var(--mute);font-size:12px'>Scene</div>`}<div class='t'><b>${ESC(x.caption||'(no caption)')}</b><div style='color:var(--mute);font-size:13px;margin-top:4px'>@${ESC(o.username||'unknown')} · ${dte(x.created_at)} · ❤ ${x.likes_count||0} · 💬 ${x.comments_count||0} · 🔖 ${x.saves_count||0} · ↗ ${x.shares_count||0}</div>${atag(ESC(x.status),'#2a2f3a')}${isPr(x)?atag('Promoted','#7a4fd6'):''}<div class='acts'>${can('promote')?`<button class='mini' data-vp='${x.id}'>${isPr(x)?'Unpromote':'Promote 7d'}</button>`:''}${can('ban')?`<button class='mini' data-vh='${x.id}' style='color:#ff5a6e'>${x.status==='published'?'Hide':'Restore'}</button><button class='mini' data-vd='${x.id}' style='color:#ff5a6e'>Delete</button>`:''}</div></div></div>`}):
  a.filter(p=>((p.display_name||'')+(p.username||'')).toLowerCase().includes(k)).map(p=>{const h=hl(p);return `<div class='ad-c'>${pic(p,48)}<div class='t'><b>${ESC(p.display_name||p.username)}</b>${p.is_admin?atag(p.admin_role==='owner'?'Owner':p.admin_role==='moderator'?'Moderator':'Admin','#3b73f2'):''}${p.verified?atag('Verified','#1f9d7a'):''}<div style='color:var(--mute);font-size:13px'>@${ESC(p.username||'')} · joined ${dte(p.created_at)} · ${v.filter(x=>x.user_id===p.id).length} videos</div>${atag(h[0],h[1]).replace('margin-left:6px','margin:6px 0 0')}<div class='acts'><button class='mini' data-man='${p.id}'>Manage</button><button class='mini' data-vu='${p.username}'>View videos</button></div></div></div>`})).join('')||"<p class='sub'>Nothing found.</p>"}
async function upd(id,patch){const p=ADM.a.find(x=>x.id===id),r=await sb.from('profiles').update(patch).eq('id',id);if(r.error)return toast('Failed: '+r.error.message);Object.assign(p,patch);renderAdmin();manage(id);toast('Updated')}
let MID=null;function manage(id){MID=id;const p=ADM.a.find(x=>x.id===id),h=hl(p),self=id===USER.id,locked=self||(p.admin_role==='owner'&&ME.admin_role!=='owner'),b=(m,t,c)=>`<button class='mini' data-m='${m}' ${c?`style='color:${c}'`:''}>${t}</button>`,pp=p.admin_perms||{};
 sheetOpen(`<h3 style='margin:0 0 4px'>${ESC(p.display_name||p.username)}</h3><div style='margin-bottom:10px'>${atag(h[0],h[1]).replace('margin-left:6px','')} <span style='color:var(--mute);font-size:13px'>${p.strikes} strike${p.strikes===1?'':'s'}${p.suspended_until&&new Date(p.suspended_until)>new Date()?' · until '+dte(p.suspended_until):''}</span></div>
 ${locked?`<p class='sub'>${self?'You cannot change your own standing.':'Only an owner can change an owner.'}</p>`:`<div class='acts' style='margin-bottom:8px'>${can('verify')?b('verify',p.verified?'Remove verified':'Verify'):''}${can('ban')?b('s+','Add strike')+b('s-','Remove strike')+b('sus7','Suspend 7d')+b('sus30','Suspend 30d')+b('sus0','Lift suspension')+b('ban',p.banned?'Unban':'Ban','#ff5a6e'):''}</div>
 ${can('admins')?`<h3 style='margin:10px 0 6px'>Admin access</h3><div class='acts'>${b('adm',p.is_admin?'Remove admin':'Make admin')}${p.is_admin&&p.admin_role!=='owner'?b('role',p.admin_role==='moderator'?'Promote to admin':'Make moderator'):''}</div>${p.is_admin&&p.admin_role==='moderator'?`<div class='acts' style='margin-top:8px'>${['verify','ban','promote'].map(k=>b('perm:'+k,(pp[k]?'✓ ':'')+k)).join('')}</div><p class='fine'>Moderators can only do what is ticked. Rules are enforced in the app.</p>`:''}`:''}`}`)}
$('#mlist').addEventListener('click',e=>{const t=e.target.closest('[data-m]');if(!t||!$('#alist'))return;const m=t.dataset.m,id=MID;if(!id)return;const p=ADM.a.find(x=>x.id===id),day=n=>new Date(Date.now()+n*864e5).toISOString();
 if(m==='verify')upd(id,{verified:!p.verified});else if(m==='s+')upd(id,{strikes:p.strikes+1});else if(m==='s-')upd(id,{strikes:Math.max(0,p.strikes-1)});
 else if(m==='sus7')upd(id,{suspended_until:day(7)});else if(m==='sus30')upd(id,{suspended_until:day(30)});else if(m==='sus0')upd(id,{suspended_until:null});
 else if(m==='ban'){if(p.banned||confirm('Ban @'+p.username+'?'))upd(id,{banned:!p.banned})}
 else if(m==='adm')upd(id,p.is_admin?{is_admin:false,admin_role:'none',admin_perms:{}}:{is_admin:true,admin_role:'moderator',admin_perms:{}});
 else if(m==='role')upd(id,{admin_role:p.admin_role==='moderator'?'admin':'moderator'});
 else if(m.startsWith('perm:')){const k=m.slice(5);upd(id,{admin_perms:{...(p.admin_perms||{}),[k]:!(p.admin_perms||{})[k]}})}});
async function openAdminTicket(id){
 if(!sb){toast('Tickets require Supabase');return}
 const t=(ADM.tk||[]).find(x=>String(x.id)===String(id)); if(!t){toast('Ticket not found');return}
 const render=async()=>{const tt=(ADM.tk||[]).find(x=>String(x.id)===String(id)); if(!tt){closeMenu();await loadAdmin();return}
  const r=await sb.from('ticket_messages').select('id,sender_role,body,created_at').eq('ticket_id',id).order('created_at',{ascending:true}); if(r.error)toast('Could not load messages: '+r.error.message);
  const msgs=r.data||[];
  const html=msgs.map(m=>`<div class='msg ${m.sender_role==='admin'?'me':'them'}'><small style='display:block;opacity:.7;font-size:11px;margin-bottom:2px'>${m.sender_role==='admin'?'Admin':'User'}${m.created_at?' · '+ESC(new Date(m.created_at).toLocaleString()):''}</small>${ESC(m.body||'')}</div>`).join('');
  sheetOpen(`<h3 style='margin:0 0 4px'>${ESC(tt.subject||'Ticket')}</h3><div style='color:var(--mute);font-size:13px;margin-bottom:8px'>${ESC(tt.user_name||'User')} · #${ESC(tt.id)} · <span class='pill ${tt.status==='closed'?'done':'open'}'>${tt.status==='open'?'Open':'Closed'}</span></div><div class='tl' id='atmsgs' style='max-height:40vh'>${html||"<p class='sub'>No messages yet.</p>"}</div><label class='lbl' style='margin-top:10px'>Reply as admin<textarea class='fld' id='atrep' placeholder='Type a reply'></textarea></label><div class='row' style='gap:8px'><button class='btn' id='atsend' style='flex:1'>Send reply</button><button class='btn o' id='attog' style='flex:1'>${tt.status==='open'?'Close ticket':'Reopen ticket'}</button></div>`);
  const L=$('#atmsgs'); if(L)L.scrollTop=L.scrollHeight;
  $('#attog').onclick=async()=>{const ns=tt.status==='open'?'closed':'open'; const u=await sb.from('support_tickets').update({status:ns,updated_at:new Date().toISOString()}).eq('id',id); if(u.error)return toast('Failed: '+u.error.message); tt.status=ns; tt.updated_at=new Date().toISOString(); await render(); renderAdmin(); updateSupCard(); toast(ns==='open'?'Ticket reopened':'Ticket closed')};
  $('#atsend').onclick=async()=>{const txt=$('#atrep').value.trim(); if(!txt)return; const ins=await sb.from('ticket_messages').insert({ticket_id:id,sender_role:'admin',user_id:USER&&USER.id||null,body:txt}); if(ins.error)return toast('Could not send: '+ins.error.message); await sb.from('support_tickets').update({updated_at:new Date().toISOString()}).eq('id',id); tt.updated_at=new Date().toISOString(); $('#atrep').value=''; await render(); renderAdmin(); toast('Reply sent')};
 };
 await render();
}
$('#abody').oninput=e=>{if(e.target.id==='aq'){ADM.q=e.target.value;renderAdmin()}};
$('#abody').onclick=async e=>{const g=s=>e.target.closest(s),t=g('[data-tab]');if(t){ADM.tab=+t.dataset.tab;renderAdmin();return}
 if(g('[data-man]')){manage(g('[data-man]').dataset.man);return}
 if(g('[data-vu]')){ADM.tab=1;ADM.q=g('[data-vu]').dataset.vu;const aq=$('#aq');if(aq)aq.value=ADM.q;renderAdmin();return}
 if(g('[data-atk]')){await openAdminTicket(g('[data-atk]').dataset.atk);return}
 if(g('[data-atog]')){const id=g('[data-atog]').dataset.atog,tt=(ADM.tk||[]).find(z=>String(z.id)===String(id)); if(!tt||!sb)return; const ns=tt.status==='open'?'closed':'open'; const r=await sb.from('support_tickets').update({status:ns,updated_at:new Date().toISOString()}).eq('id',id); if(r.error)return toast('Failed: '+r.error.message); tt.status=ns; tt.updated_at=new Date().toISOString(); renderAdmin(); updateSupCard(); toast(ns==='open'?'Ticket reopened':'Ticket closed'); return}
 const vd=g('[data-vd]');if(vd){const id=vd.dataset.vd;if(!confirm('Delete this video permanently?'))return;const r=await sb.from('videos').delete().eq('id',id);if(r.error)return toast('Failed: '+r.error.message);ADM.v=ADM.v.filter(y=>y.id!==id);renderAdmin();toast('Video deleted');return}
 const vp=g('[data-vp]'),vh=g('[data-vh]'),x=(ADM.v||[]).find(y=>y.id===(vp||vh||{dataset:{}}).dataset[vp?'vp':'vh']);
 if(x&&(vp||vh)){const patch=vp?(isPr(x)?{promoted:false,promoted_until:null}:{promoted:true,promoted_until:new Date(Date.now()+7*864e5).toISOString()}):{status:x.status==='published'?'removed':'published'},r=await sb.from('videos').update(patch).eq('id',x.id);if(r.error)return toast('Failed: '+r.error.message);Object.assign(x,patch);renderAdmin();toast('Updated')}};
$('#adminBtn').onclick=()=>{show('admin');$('#nav [data-s=profile]').setAttribute('aria-current','page');loadAdmin()};
$('#aback').onclick=()=>show('settings');
/* Studio + camera */
$('#app').insertAdjacentHTML('beforeend',"<div id='studio'></div><div id='cam'><canvas id='ccv' width='720' height='1280'></canvas><video id='cvid' playsinline muted style='display:none'></video><video id='crev' playsinline controls loop></video><div class='ctop'><button class='ib glass' id='cx' aria-label='Close'>✕</button><button class='ib glass' id='cflip' aria-label='Flip camera'>⟲</button></div><div class='cbot'><div class='cchips' id='cfx'></div><div class='cchips' id='cst'></div><input class='fld' id='ccp' maxlength='40' placeholder='Add a caption'><div class='crow' id='cr1'><button class='rec' id='crec' aria-label='Record'><i></i></button></div><div class='crow' id='cr2' style='display:none'><button class='btn o' id='cre'>Retake</button><button class='btn' id='cpo'>Post</button></div></div></div>");
const oS=[...$$('.btn')].find(b=>b.textContent.trim()==='Open Studio');if(oS){oS.removeAttribute('data-toast');oS.onclick=openStudio}
let SP={coins:0,last_claim:null},STAB=0;
const STT=['Overview','Rewards','Subscribers','Gifts'],MS=[['Post your first video',1,25],['Post 5 videos',5,100],['Post 10 videos',10,250]];
async function openStudio(){if(!USER)return toast('Log in to open Studio');$('#studio').classList.add('open');const{data}=await sb.from('profiles').select('coins,last_claim').eq('id',USER.id).maybeSingle();if(data)SP=data;renderStudio()}
async function addCoins(n,extra){const r=await sb.from('profiles').update({coins:(SP.coins||0)+n,...extra}).eq('id',USER.id);if(r.error)return toast('Failed: '+r.error.message);SP.coins=(SP.coins||0)+n;Object.assign(SP,extra);toast('+'+n+' coins');renderStudio()}
function renderStudio(){const sub=KV.get('sub',{on:false,price:4.99}),done=KV.get('ms',[]),can=!SP.last_claim||Date.now()-new Date(SP.last_claim)>864e5,n=MINE.length;let b='';
 if(STAB===0)b=`<div class='ad-stats'><div class='ad-s'><b>${n}</b><span>Videos</span></div><div class='ad-s'><b>${SP.coins||0}</b><span>Coins</span></div><div class='ad-s'><b>0</b><span>Subscribers</span></div><div class='ad-s'><b>${sub.on?'$'+sub.price:'Off'}</b><span>Subscription</span></div></div><button class='btn' id='spost' style='width:100%'>Create a video</button>`;
 if(STAB===1)b=`<div class='ad-c'><div class='t'><b>Daily reward</b><div style='color:var(--mute);font-size:13px'>10 coins every 24 hours</div></div><button class='btn' data-claim='1' ${can?'':'disabled'}>${can?'Claim':'Claimed'}</button></div><h3>Milestones</h3>${MS.map((m,i)=>`<div class='ad-c'><div class='t'><b>${m[0]}</b><div style='color:var(--mute);font-size:13px'>${Math.min(n,m[1])}/${m[1]} · ${m[2]} coins</div></div><button class='btn' data-ms='${i}' ${n>=m[1]&&!done.includes(i)?'':'disabled'}>${done.includes(i)?'Claimed':'Claim'}</button></div>`).join('')}<p class='fine'>Coins are for gifts in the app. Cash payouts are not available yet.</p>`;
 if(STAB===2)b=`<div class='ad-c'><div class='t'><b>Accept subscribers</b><div style='color:var(--mute);font-size:13px'>Fans pay monthly for perks</div></div><button class='sw' id='ssub' role='switch' aria-checked='${sub.on}' aria-label='Accept subscribers'></button></div><h3>Monthly price</h3><div class='cchips'>${[2.99,4.99,9.99].map(p=>`<button data-price='${p}' class='${sub.price===p?'on':''}'>$${p}</button>`).join('')}</div><h3>Perks</h3><p class='sub'>Subscriber badge · subscriber-only videos · early access to lives</p><p class='fine'>Preview only. No real payments are taken.</p>`;
 if(STAB===3)b=`<div class='ad-s' style='margin-bottom:12px'><b>${SP.coins||0}</b><span>Your coins</span></div><h3>Gifts viewers can send</h3>${GIFTS.map(g=>`<div class='srow'>${ESC(g[0])}<span class='ch'>${g[2]} coins</span></div>`).join('')}<button class='btn o' id='slive' style='width:100%;margin-top:12px'>See how a live looks</button><p class='fine'>Hosting your own live is not built yet.</p>`;
 $('#studio').innerHTML=`<div class='row' style='margin-bottom:10px'><button class='ib glass' id='sbk' aria-label='Back'><svg viewBox='0 0 24 24'><path d='M15 5l-7 7 7 7'/></svg></button><h1 style='font-size:24px'>Studio</h1></div><div class='ad-tabs'>${STT.map((t,i)=>`<button data-st='${i}' aria-selected='${i===STAB}'>${t}</button>`).join('')}</div>${b}`;}
$('#studio').onclick=e=>{const g=s=>e.target.closest(s);if(g('#sbk'))return $('#studio').classList.remove('open');
 if(g('[data-st]')){STAB=+g('[data-st]').dataset.st;return renderStudio()}
 if(g('[data-claim]'))return addCoins(10,{last_claim:new Date().toISOString()});
 if(g('[data-ms]')){const i=+g('[data-ms]').dataset.ms;KV.set('ms',KV.get('ms',[]).concat(i));return addCoins(MS[i][2],{})}
 if(g('#ssub')){const s=KV.get('sub',{on:false,price:4.99});s.on=!s.on;KV.set('sub',s);return renderStudio()}
 if(g('[data-price]')){const s=KV.get('sub',{on:false,price:4.99});s.price=+g('[data-price]').dataset.price;KV.set('sub',s);return renderStudio()}
 if(g('#spost')){$('#studio').classList.remove('open');return $('#mk').click()}
 if(g('#slive')){$('#studio').classList.remove('open');openLive(0)}};
/* camera */
const FX=[['Normal',''],['Warm','sepia(.35) saturate(1.3)'],['Cool','saturate(1.2) hue-rotate(15deg) brightness(1.05)'],['B&W','grayscale(1)'],['Vivid','saturate(1.8) contrast(1.1)'],['Vintage','sepia(.6) contrast(.9) brightness(1.1)'],['Dream','blur(1px) brightness(1.15) saturate(1.3)']],CSTK=['🔥','😂','❤️','✨','😎','🎉','👀','💯'];
let CAM={fx:0,st:[],face:'user',stream:null,raf:0,rec:null,ch:[],blob:null,ext:'webm',tm:0};
function camDraw(){const x=$('#ccv').getContext('2d'),v=$('#cvid');
 x.fillStyle='#000';x.fillRect(0,0,720,1280);
 if(v.videoWidth){const s=Math.max(720/v.videoWidth,1280/v.videoHeight),w=v.videoWidth*s,h=v.videoHeight*s;x.save();x.filter=FX[CAM.fx][1]||'none';if(CAM.face==='user'){x.translate(720,0);x.scale(-1,1)}x.drawImage(v,(720-w)/2,(1280-h)/2,w,h);x.restore();x.filter='none'}
 x.textAlign='center';CAM.st.forEach(s=>{x.font='120px serif';x.fillText(s.e,s.x,s.y)});
 const c=$('#ccp').value.trim();if(c){x.font='800 52px Manrope,sans-serif';x.lineWidth=10;x.strokeStyle='rgba(0,0,0,.7)';x.strokeText(c,360,1060,640);x.fillStyle='#fff';x.fillText(c,360,1060,640)}
 CAM.raf=requestAnimationFrame(camDraw)}
async function camStart(){if(!USER)return toast('Log in to post');if(SUSP)return toast('Your account is suspended until '+dte(SUSP));
 CAM.blob=null;$('#cam').classList.add('open');camMode(0);
 $('#cfx').innerHTML=FX.map((f,i)=>`<button data-fx='${i}' class='${i===CAM.fx?'on':''}'>${f[0]}</button>`).join('');
 $('#cst').innerHTML=CSTK.map(s=>`<button data-s='${s}'>${s}</button>`).join('')+"<button data-s='clear'>Clear</button>";
 try{CAM.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:CAM.face,width:{ideal:1280},height:{ideal:720}},audio:true});const v=$('#cvid');v.srcObject=CAM.stream;await v.play();cancelAnimationFrame(CAM.raf);camDraw()}catch(e){toast('Camera not available: '+(e.message||e.name));camClose()}}
function camMode(r){$('#crev').style.display=r?'block':'none';$('#ccv').style.display=r?'none':'block';$('#cr1').style.display=r?'none':'flex';$('#cr2').style.display=r?'flex':'none';$('#cfx').style.display=$('#cst').style.display=r?'none':'flex'}
function camClose(){clearTimeout(CAM.tm);cancelAnimationFrame(CAM.raf);if(CAM.rec&&CAM.rec.state!=='inactive'){CAM.rec.onstop=null;CAM.rec.stop()}CAM.stream&&CAM.stream.getTracks().forEach(t=>t.stop());CAM.stream=null;$('#crec').classList.remove('on');$('#cam').classList.remove('open')}
function camRecToggle(){const b=$('#crec');if(CAM.rec&&CAM.rec.state==='recording'){CAM.rec.stop();return}
 if(!window.MediaRecorder)return toast('Recording is not supported on this browser');
 const cs=$('#ccv').captureStream(30);CAM.stream.getAudioTracks().forEach(t=>cs.addTrack(t));
 const mt=['video/webm;codecs=vp8,opus','video/webm','video/mp4'].find(t=>MediaRecorder.isTypeSupported(t))||'';CAM.ext=/mp4/.test(mt)?'mp4':'webm';CAM.ch=[];
 CAM.rec=new MediaRecorder(cs,mt?{mimeType:mt}:{});CAM.rec.ondataavailable=e=>e.data.size&&CAM.ch.push(e.data);
 CAM.rec.onstop=()=>{clearTimeout(CAM.tm);b.classList.remove('on');CAM.blob=new Blob(CAM.ch,{type:'video/'+CAM.ext});const r=$('#crev');r.src=URL.createObjectURL(CAM.blob);r.play().catch(()=>{});camMode(1)};
 CAM.rec.start();b.classList.add('on');CAM.tm=setTimeout(()=>CAM.rec.state==='recording'&&CAM.rec.stop(),30000)}
async function camPost(){if(!CAM.blob)return;const bt=$('#cpo');bt.disabled=true;toast('Posting…');
 const path=`${USER.id}/${crypto.randomUUID()}.${CAM.ext}`,up=await sb.storage.from('arc-videos').upload(path,CAM.blob,{contentType:CAM.blob.type||'video/'+CAM.ext});
 if(up.error){bt.disabled=false;return toast('Upload failed: '+up.error.message)}
 const r=await sb.from('videos').insert({user_id:USER.id,storage_path:path,caption:$('#ccp').value.trim()||'New video'});bt.disabled=false;
 if(r.error)return toast('Could not save: '+r.error.message);camClose();$('#ccp').value='';toast('Posted!');onSignedIn(USER)}
$('#cam').onclick=e=>{const g=s=>e.target.closest(s);if(g('#cx'))camClose();else if(g('#crec'))camRecToggle();
 else if(g('#cflip')){CAM.face=CAM.face==='user'?'environment':'user';CAM.stream&&CAM.stream.getTracks().forEach(t=>t.stop());camStart()}
 else if(g('[data-fx]')){CAM.fx=+g('[data-fx]').dataset.fx;$$('#cfx button').forEach((b,i)=>b.classList.toggle('on',i===CAM.fx))}
 else if(g('[data-s]')){const s=g('[data-s]').dataset.s;if(s==='clear')CAM.st=[];else CAM.st.push({e:s,x:160+Math.random()*400,y:300+Math.random()*600})}
 else if(g('#cre')){CAM.blob=null;camMode(0)}else if(g('#cpo'))camPost()};


async function openUserProfile(u){
 if(!u)return; const self = USER && (u.id===USER.id || (u.username && u.username===MY_USERNAME));
 if(self){ show('profile'); $('#nav [data-s=profile]').setAttribute('aria-current','page'); return; }
 const name = u.display_name||u.name||u.username||'User';
 const handle = u.username||u.h||'';
 const vids = [...FY,...FO].filter(v=> (u.id && v.user_id===u.id) || (handle && v.h===handle));
 const grid = vids.length ? vids.slice(0,12).map(m=>`<div class='th'>${m.vid?`<video src='${esc2(m.vid)}#t=0.1' muted playsinline preload='metadata' style='width:100%;height:100%;object-fit:cover'></video>`:sc(m.s||0)}<div class='ov'>${esc2(m.cap||'')}</div></div>`).join('') : `<p class='sub'>No public videos yet.</p>`;
 sheetOpen(`<div class='row' style='gap:12px;align-items:center;margin-bottom:10px'>${av(name,u.col||'#3b73f2','width:54px;height:54px;font-size:16px',PROFILE_PICS.get(name)||PROFILE_PICS.get(handle)||'')}<div><b style='font-size:18px'>${esc2(name)}</b><div style='color:var(--mute)'>@${esc2(handle||'user')}</div></div></div><div class='grid' style='margin-top:8px'>${grid}</div>`);
}
/* === cloud engagement + profile stats helpers (appended fix) === */
function cloudVideoId(v){return v&&v.id&&/^[0-9a-f]{8}-/i.test(String(v.id))?String(v.id):null}
function isUuidLike(id){return !!(id&&/^[0-9a-f]{8}-/i.test(String(id)))}
async function refreshProfileStats(){const pf=$('#pFollowers'),pg=$('#pFollowing'),pl=$('#pLikes'); if(!pf||!pg||!pl)return;
 let followers=0,following=(Array.isArray(KV.get('foll',[]))?KV.get('foll',[]):[]).length,likes=0;
 try{
  if(sb&&USER){
   try{const vq=await sb.from('videos').select('likes_count').eq('user_id',USER.id); if(!vq.error&&Array.isArray(vq.data))likes=vq.data.reduce((n,r)=>n+(+r.likes_count||0),0); else likes=(MINE||[]).reduce((n,v)=>n+(+v.l||0),0)}catch(e){likes=(MINE||[]).reduce((n,v)=>n+(+v.l||0),0)}
   try{const fr=await sb.from('follows').select('*',{count:'exact',head:true}).eq('following_id',USER.id); if(!fr.error&&fr.count!=null)followers=fr.count}catch(e){}
   try{const fg=await sb.from('follows').select('*',{count:'exact',head:true}).eq('follower_id',USER.id); if(!fg.error&&fg.count!=null)following=fg.count}catch(e){}
  } else { likes=(MINE||[]).reduce((n,v)=>n+(+v.l||0),0); }
 }catch(e){}
 pf.textContent=fmt(followers||0); pg.textContent=fmt(following||0); pl.textContent=fmt(likes||0);
}
async function refreshProfileStatsSafe(){try{await refreshProfileStats()}catch(e){}}
async function loadMyReactionsSafe(){if(!(sb&&USER))return; try{
 const lset=new Set(), sset=new Set();
 try{const lr=await sb.from('video_likes').select('video_id').eq('user_id',USER.id); if(!lr.error)(lr.data||[]).forEach(x=>x&&x.video_id&&lset.add(String(x.video_id)))}catch(e){}
 try{const sr=await sb.from('video_saves').select('video_id').eq('user_id',USER.id); if(!sr.error)(sr.data||[]).forEach(x=>x&&x.video_id&&sset.add(String(x.video_id)))}catch(e){}
 const mark=(arr)=>{(arr||[]).forEach(v=>{const id=cloudVideoId(v); if(!id)return; if(lset.has(id)){let a=KV.get('liked',[]).filter(x=>x.key!==vKey(v)); a.unshift(vSnap(v)); KV.set('liked',a.slice(0,200))} if(sset.has(id)){let a=KV.get('saved',[]).filter(x=>x.key!==vKey(v)); a.unshift(vSnap(v)); KV.set('saved',a.slice(0,200))}})};
 mark(FY); mark(FO); mark(MINE);
}catch(e){}}
async function bumpCount(v,field,delta){if(!(sb&&USER))return; const id=cloudVideoId(v); if(!id)return; try{const r=await sb.rpc('bump_video_counter',{vid:id,field,delta}); if(!r||r.error){const cur=await sb.from('videos').select(field).eq('id',id).maybeSingle(); if(cur&&!cur.error&&cur.data){const val=Math.max(0,(+cur.data[field]||0)+delta); await sb.from('videos').update({[field]:val}).eq('id',id)} }}catch(e){}}
async function persistLikeCloud(v,on){if(!(sb&&USER))return; const id=cloudVideoId(v); if(!id)return; try{ if(on){const r=await sb.from('video_likes').insert({video_id:id,user_id:USER.id}); if(r.error&&r.error.code!=='23505')return;} else {await sb.from('video_likes').delete().eq('video_id',id).eq('user_id',USER.id)} await bumpCount(v,'likes_count',on?1:-1);}catch(e){}}
async function persistSaveCloud(v,on){if(!(sb&&USER))return; const id=cloudVideoId(v); if(!id)return; try{ if(on){const r=await sb.from('video_saves').insert({video_id:id,user_id:USER.id}); if(r.error&&r.error.code!=='23505')return;} else {await sb.from('video_saves').delete().eq('video_id',id).eq('user_id',USER.id)} await bumpCount(v,'saves_count',on?1:-1);}catch(e){}}
async function persistShareCloud(v){if(!(sb&&USER))return; try{await bumpCount(v,'shares_count',1)}catch(e){}}
async function persistCommentCloud(v,text,parentId){if(!(sb&&USER))return {ok:false}; const id=cloudVideoId(v); if(!id)return {ok:false,local:true}; try{const payload={video_id:id,user_id:USER.id,body:text}; if(parentId)payload.parent_id=parentId; const r=await sb.from('video_comments').insert(payload).select('id,body,created_at,user_id,parent_id,likes_count').single(); if(r.error&&parentId){const r2=await sb.from('video_comments').insert({video_id:id,user_id:USER.id,body:text}).select('id,body,created_at,user_id').single(); if(r2.error)return {ok:false,error:r2.error}; await bumpCount(v,'comments_count',1); return {ok:true,row:r2.data,noParent:true}} if(r.error)return {ok:false,error:r.error}; await bumpCount(v,'comments_count',1); return {ok:true,row:r.data}}catch(e){return {ok:false,error:e}}}
function syncFeedCardFor(v){$$('.card').forEach(el=>{const vv=el._v; if(!vv||vKey(vv)!==vKey(v))return; const lb=el.querySelector('[data-k=like] .n'),cb=el.querySelector('[data-k=cm] .n'),sbN=el.querySelector('[data-k=save] .n'),shN=el.querySelector('[data-k=sh] .n'); const lbB=el.querySelector('[data-k=like]'),sbB=el.querySelector('[data-k=save]'); if(lb)lb.textContent=fmt(v.l||0); if(cb)cb.textContent=fmt(v.c||CM&&CV&&vKey(CV)===vKey(v)?CM.length:v.c||0); if(sbN)sbN.textContent=hasSave(v)?'Saved':'Save'; if(shN)shN.textContent=(v.sh||0)?fmt(v.sh):'Share'; if(lbB)lbB.setAttribute('aria-pressed',hasLike(v)?'true':'false'); if(sbB)sbB.setAttribute('aria-pressed',hasSave(v)?'true':'false');}); if(CV&&vKey(CV)===vKey(v)){const ct=$('#ct'); if(ct)ct.textContent=(fmt(v.c||CM.length||0)+' comments')}}

// override like/save/share to persist (called by existing handlers too)
const _setLike=setLike; setLike=function(v,on){_setLike(v,on)}; // keep KV behavior
const _setSave=setSave; setSave=function(v,on){_setSave(v,on)};

async function toggleLikePersist(v,on){setLike(v,on); syncFeedCardFor(v); await persistLikeCloud(v,on); await refreshProfileStatsSafe()}
async function toggleSavePersist(v,on){setSave(v,on); syncFeedCardFor(v); await persistSaveCloud(v,on)}
async function doSharePersist(v){v.sh=(v.sh||0)+1; syncFeedCardFor(v); await persistShareCloud(v)}

// patch follow to pass target user id from feed items
const _doFollow=doFollow; // already async now; keep

// load cloud content for everyone when available (same live feed for all users)
if(sb){ loadPublicFeed().catch(()=>{}); }

/* Visual Lens - custom WebGL camera: live filters, beauty, zoom, timer, pause/resume, stickers, upload */
(()=>{
const FX=[['Normal','#555'],['Vivid','linear-gradient(135deg,#ff3b5c,#ffb000)'],['Warm','#e9824f'],['Cool','#3b8bf2'],['Noir','linear-gradient(#fff,#000)'],['Film','#a8895a'],['Neon','linear-gradient(135deg,#7a00ff,#00ffe0)'],['Glitch','linear-gradient(90deg,#f00,#0ff)'],['Dream','#d9b8ff'],['Pixel','repeating-conic-gradient(#3b73f2 0 25%,#fff 0 50%) 0/12px 12px'],['Mirror','linear-gradient(90deg,#1f9d7a 50%,#7be0c3 50%)'],['Comic','#ffd23b']];
const EM=['🔥','😂','❤️','✨','😎','🎉','👀','💯','🌈','⭐','👑','💙'];
const L={fx:0,amt:1,sm:.25,br:0,zoom:1,face:'user',dur:30,tm:0,items:[],acc:0,t0:0,paused:false,ch:[],ptr:new Map()};
const VS='attribute vec2 p;varying vec2 v;uniform vec4 u;void main(){gl_Position=vec4(p,0,1);vec2 q=p*.5+.5;q=.5+(q-.5)*u.xy/u.z;if(u.w>.5)q.x=1.-q.x;v=q;}';
const FS=`precision mediump float;varying vec2 v;uniform sampler2D t;uniform int m;uniform float a,s,b,tm;
vec3 S(vec2 p){return texture2D(t,p).rgb;}
void main(){vec2 p=v;
if(m==10)p.x=.5-abs(p.x-.5);
if(m==9)p=floor(p*vec2(72.,128.))/vec2(72.,128.);
if(m==7)p.x+=step(.96,fract(sin(floor(p.y*30.+tm*9.)*91.3)*437.5))*.04;
vec3 o=S(p),c=o;
if(m==7)c=vec3(S(p+vec2(.008,0.)).r,o.g,S(p-vec2(.008,0.)).b);
vec3 bl=(S(p+vec2(.004,0.))+S(p-vec2(.004,0.))+S(p+vec2(0.,.003))+S(p-vec2(0.,.003)))*.25;
vec3 r=c;float Y=dot(c,vec3(.3,.59,.11));
if(m==1)r=mix(vec3(Y),c,1.8)*1.08;
if(m==2)r=c*vec3(1.1,1.,.84)+vec3(.04,.01,-.02);
if(m==3)r=c*vec3(.88,1.,1.12)+vec3(-.01,.01,.04);
if(m==4)r=vec3((Y-.5)*1.3+.5);
if(m==5){r=mix(c,vec3(Y)*vec3(1.2,1.,.8),.5);r+=(fract(sin(dot(v+tm,vec2(12.9,78.2)))*43758.5)-.5)*.12;r*=1.-.6*pow(length(v-.5),2.);}
if(m==6)r=mix(vec3(.1,0.,.3),vec3(0.,1.,.9),Y)+vec3(.5,0.,.4)*pow(Y,3.);
if(m==8)r=c*.7+(bl+vec3(.08,.04,.1))*.6+.1*pow(Y,2.);
if(m==11){r=floor(c*4.+.5)/4.;}
vec3 f=mix(o,r,a);f=mix(f,bl,s*.8)+b;gl_FragColor=vec4(f,1.);}`;
let G,U={},B=0;const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const T=m=>window.toast&&toast(m);
function initGL(){const c=$('#lgl');G=c.getContext('webgl',{preserveDrawingBuffer:true});if(!G)return false;
 const sh=(t,s)=>{const x=G.createShader(t);G.shaderSource(x,s);G.compileShader(x);return x},pr=G.createProgram();
 G.attachShader(pr,sh(G.VERTEX_SHADER,VS));G.attachShader(pr,sh(G.FRAGMENT_SHADER,FS));G.linkProgram(pr);G.useProgram(pr);
 const bf=G.createBuffer();G.bindBuffer(G.ARRAY_BUFFER,bf);G.bufferData(G.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),G.STATIC_DRAW);
 const l=G.getAttribLocation(pr,'p');G.enableVertexAttribArray(l);G.vertexAttribPointer(l,2,G.FLOAT,false,0,0);
 ['u','m','a','s','b','tm'].forEach(n=>U[n]=G.getUniformLocation(pr,n));
 const tx=G.createTexture();G.bindTexture(G.TEXTURE_2D,tx);G.pixelStorei(G.UNPACK_FLIP_Y_WEBGL,true);
 [[G.TEXTURE_MIN_FILTER,G.LINEAR],[G.TEXTURE_MAG_FILTER,G.LINEAR],[G.TEXTURE_WRAP_S,G.CLAMP_TO_EDGE],[G.TEXTURE_WRAP_T,G.CLAMP_TO_EDGE]].forEach(a=>G.texParameteri(G.TEXTURE_2D,...a));
 G.viewport(0,0,720,1280);return true}
const el=()=>L.acc+(L.rec&&L.rec.state==='recording'?performance.now()-L.t0:0);
function frame(ts){L.raf=requestAnimationFrame(frame);const v=$('#lv'),o=$('#lout').getContext('2d');
 o.fillStyle='#000';o.fillRect(0,0,720,1280);
 if(v.readyState>=2&&v.videoWidth){const va=v.videoWidth/v.videoHeight,ta=720/1280;
  if(G){G.uniform4f(U.u,va>ta?ta/va:1,va>ta?1:va/ta,L.zoom,L.face==='user'?1:0);G.uniform1i(U.m,L.fx);G.uniform1f(U.a,L.amt);G.uniform1f(U.s,L.sm);G.uniform1f(U.b,L.br);G.uniform1f(U.tm,ts/1000%100);
   G.texImage2D(G.TEXTURE_2D,0,G.RGB,G.RGB,G.UNSIGNED_BYTE,v);G.drawArrays(G.TRIANGLE_STRIP,0,4);o.drawImage($('#lgl'),0,0)}
  else{const s=Math.max(720/v.videoWidth,1280/v.videoHeight)*L.zoom,w=v.videoWidth*s,h=v.videoHeight*s;o.save();if(L.face==='user'){o.translate(720,0);o.scale(-1,1)}o.drawImage(v,(720-w)/2,(1280-h)/2,w,h);o.restore()}}
 o.textAlign='center';o.textBaseline='middle';
 L.items.forEach(i=>{if(i.e){o.font=i.z+'px serif';o.fillText(i.e,i.x*720,i.y*1280)}else{o.font='800 '+i.z*.45+'px Manrope,sans-serif';o.lineWidth=9;o.strokeStyle='#0009';o.strokeText(i.t,i.x*720,i.y*1280,680);o.fillStyle=i.c;o.fillText(i.t,i.x*720,i.y*1280,680)}});
 const e=el();$('#lrec .pg').style.strokeDashoffset=251.3*(1-Math.min(1,e/(L.dur*1000)));
 if(L.rec&&L.rec.state!=='inactive'){$('#ltm').textContent=(e/1000).toFixed(1)+'s';if(e>=L.dur*1000)stop()}}
function html(){$('#app').insertAdjacentHTML('beforeend',`<div id="lens"><canvas id="lgl" width="720" height="1280"></canvas><canvas id="lout" width="720" height="1280"></canvas><video id="lv" playsinline muted></video><div class="grid3"></div>
<div class="ltop"><button class="ib glass" data-a="x" aria-label="Close">✕</button><div class="ldur" id="ldur">${[15,30,60].map(d=>`<button data-d="${d}" class="${d===30?'on':''}">${d}s</button>`).join('')}</div><b id="ltm" style="min-width:44px;text-align:right"></b></div>
<div class="lrail"><button data-a="flip" aria-label="Flip">⟲</button><button data-a="flash" aria-label="Flash">⚡</button><button data-a="timer" aria-label="Timer">⏱<small id="ltl">Off</small></button><button data-a="grid" aria-label="Grid">▦</button><button data-a="sl" aria-label="Adjust">🎚</button><button data-a="txt" aria-label="Text">Aa</button><button data-a="stk" aria-label="Stickers">😊</button></div>
<div id="lsl"><label>Strength<input type="range" id="rAmt" min="0" max="1" step=".05" value="1"></label><label>Smooth<input type="range" id="rSm" min="0" max="1" step=".05" value=".25"></label><label>Brightness<input type="range" id="rBr" min="-.2" max=".25" step=".01" value="0"></label><label>Zoom<input type="range" id="rZm" min="1" max="4" step=".05" value="1"></label></div>
<div id="lst">${EM.map(e=>`<button data-e="${e}">${e}</button>`).join('')}</div><div id="lcnt"></div><div id="lflash"></div><div id="ltr">🗑</div>
<div class="lbot"><div class="lfx" id="lfx">${FX.map((f,i)=>`<button data-f="${i}" class="${i?'':'on'}"><i style="--c:${f[1]}"></i>${f[0]}</button>`).join('')}</div>
<div class="lctl"><button data-a="up" aria-label="Upload video">⬆</button><button id="lrec" data-a="rec" aria-label="Record"><svg viewBox="0 0 88 88"><circle class="bg" cx="44" cy="44" r="40"/><circle class="pg" cx="44" cy="44" r="40"/></svg><i></i></button><button id="lps" data-a="ps" aria-label="Pause">⏸</button></div></div>
<input type="file" id="lfile" accept="video/*" hidden>
<div id="lrev"><video id="lrv" playsinline controls loop></video><div class="rb"><input class="fld" id="lcap" maxlength="140" placeholder="Write a caption #tags"><div class="row"><button class="btn o" data-a="re">Retake</button><button class="btn o" data-a="save">Save</button><button class="btn" data-a="post" id="lpost">Post</button></div></div></div></div>`)}
function setFx(i){L.fx=(i+FX.length)%FX.length;$$('#lfx button').forEach((b,k)=>{b.classList.toggle('on',k===L.fx);if(k===L.fx)b.scrollIntoView({inline:'center',block:'nearest',behavior:'smooth'})});const f=$('#lflash');f.textContent=FX[L.fx][0];f.classList.add('s');setTimeout(()=>f.classList.remove('s'),50)}
async function open(){if(!USER)return T('Log in to post');if(SUSP)return T('Your account is suspended');
 if(!$('#lens')){html();initGL();bind()}
 $('#lens').classList.add('open');rev(0);L.items=[];L.acc=0;$('#ltm').textContent='';
 try{L.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:L.face,width:{ideal:1280},height:{ideal:720}},audio:true})}
 catch(e){try{L.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:L.face}})}catch(e2){T('Camera not available: '+(e2.message||e2.name));return close()}}
 const v=$('#lv');v.srcObject=L.stream;await v.play().catch(()=>{});cancelAnimationFrame(L.raf);L.raf=requestAnimationFrame(frame)}
function close(){cancelAnimationFrame(L.raf);clearTimeout(L.ct);if(L.rec&&L.rec.state!=='inactive'){L.rec.onstop=null;L.rec.stop()}L.stream&&L.stream.getTracks().forEach(t=>t.stop());L.stream=null;const l=$('#lens');if(l){l.classList.remove('open','rec');}}
function rev(on){$('#lrev').classList.toggle('open',!!on);if(!on){const r=$('#lrv');r.pause();r.removeAttribute('src')}}
function count(n,cb){const c=$('#lcnt');if(!n)return cb();c.textContent=n;L.ct=setTimeout(()=>{c.textContent='';count(n-1,cb)},1000);navigator.vibrate&&navigator.vibrate(20)}
function start(){if(L.rec&&L.rec.state!=='inactive')return stop();if(!window.MediaRecorder)return T('Recording is not supported on this browser');
 count(L.tm,()=>{const cs=$('#lout').captureStream(30);L.stream.getAudioTracks().forEach(t=>cs.addTrack(t));
  const mt=['video/webm;codecs=vp8,opus','video/webm','video/mp4'].find(t=>MediaRecorder.isTypeSupported(t))||'';L.ext=/mp4/.test(mt)?'mp4':'webm';L.ch=[];
  L.rec=new MediaRecorder(cs,mt?{mimeType:mt,videoBitsPerSecond:3.5e6}:{});L.rec.ondataavailable=e=>e.data.size&&L.ch.push(e.data);
  L.rec.onstop=()=>{$('#lens').classList.remove('rec');L.acc=0;L.blob=new Blob(L.ch,{type:'video/'+L.ext});review()};
  L.acc=0;L.t0=performance.now();L.rec.start(250);$('#lens').classList.add('rec')})}
function stop(){if(L.rec&&L.rec.state!=='inactive')L.rec.stop()}
function pause(){if(!L.rec)return;if(L.rec.state==='recording'){L.acc+=performance.now()-L.t0;L.rec.pause();$('#lps').textContent='▶'}else if(L.rec.state==='paused'){L.t0=performance.now();L.rec.resume();$('#lps').textContent='⏸'}}
function review(){const r=$('#lrv');r.src=URL.createObjectURL(L.blob);r.play().catch(()=>{});rev(1)}
async function post(){if(!L.blob)return;const b=$('#lpost');b.disabled=true;T('Uploading…');
 const ext=L.ext||'mp4',path=`${USER.id}/${crypto.randomUUID()}.${ext}`,up=await sb.storage.from('arc-videos').upload(path,L.blob,{contentType:L.blob.type||'video/'+ext});
 if(up.error){b.disabled=false;return T('Upload failed: '+up.error.message)}
 const r=await sb.from('videos').insert({user_id:USER.id,storage_path:path,caption:$('#lcap').value.trim()||'New video'});b.disabled=false;
 if(r.error)return T('Could not save: '+r.error.message);
 close();$('#lcap').value='';L.blob=null;T('Posted!');await loadPublicFeed();
 const m=FY.filter(v=>v.user_id===USER.id);MINE=m;show('home');homeTab(2);prof(0)}
function pos(e){const r=$('#lout').getBoundingClientRect();return{x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height}}
function bind(){const l=$('#lens'),cv=$('#lout');
 l.onclick=e=>{const g=s=>e.target.closest(s);let b;
  if(b=g('[data-a]')){const a=b.dataset.a;
   if(a==='x')close();else if(a==='rec')start();else if(a==='ps')pause();
   else if(a==='flip'){L.face=L.face==='user'?'environment':'user';L.stream&&L.stream.getTracks().forEach(t=>t.stop());open()}
   else if(a==='flash'){const t=L.stream&&L.stream.getVideoTracks()[0];if(!t||!(t.getCapabilities&&t.getCapabilities().torch))return T('Flash not supported on this camera');L.torch=!L.torch;t.applyConstraints({advanced:[{torch:L.torch}]});b.classList.toggle('on',L.torch)}
   else if(a==='timer'){L.tm=L.tm===0?3:L.tm===3?10:0;$('#ltl').textContent=L.tm?L.tm+'s':'Off';b.classList.toggle('on',!!L.tm)}
   else if(a==='grid'){l.classList.toggle('g');b.classList.toggle('on')}
   else if(a==='sl'){$('#lsl').classList.toggle('open');b.classList.toggle('on')}
   else if(a==='stk'){$('#lst').classList.toggle('open');b.classList.toggle('on')}
   else if(a==='txt'){const t=(prompt('Text on video')||'').trim();if(t)L.items.push({t:t.slice(0,40),x:.5,y:.4,z:90,c:'#fff'})}
   else if(a==='up')$('#lfile').click();
   else if(a==='re'){L.blob=null;rev(0)}
   else if(a==='save'&&L.blob){const x=document.createElement('a');x.href=URL.createObjectURL(L.blob);x.download='visual-'+Date.now()+'.'+L.ext;x.click()}
   else if(a==='post')post();return}
  if(b=g('[data-d]')){L.dur=+b.dataset.d;$$('#ldur button').forEach(x=>x.classList.toggle('on',x===b))}
  else if(b=g('[data-f]'))setFx(+b.dataset.f);
  else if(b=g('[data-e]')){L.items.push({e:b.dataset.e,x:.3+Math.random()*.4,y:.35+Math.random()*.25,z:150});$('#lst').classList.remove('open');$('[data-a=stk]').classList.remove('on')}};
 $('#lfile').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>200e6)return T('Video is too large (max 200 MB)');L.blob=f;L.ext=(f.name.split('.').pop()||'mp4').toLowerCase();review()};
 [['rAmt','amt'],['rSm','sm'],['rBr','br'],['rZm','zoom']].forEach(([id,k])=>$('#'+id).oninput=e=>L[k]=+e.target.value);
 /* gestures: drag stickers, swipe = change filter, pinch = zoom */
 let drag=null,sx=0,pd=0,pz=1;
 cv.onpointerdown=e=>{cv.setPointerCapture(e.pointerId);L.ptr.set(e.pointerId,e);const p=pos(e);
  if(L.ptr.size===2){const [a,b]=[...L.ptr.values()];pd=Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY);pz=L.zoom;drag=null;return}
  sx=e.clientX;drag=null;for(let i=L.items.length;i--;){const it=L.items[i];if(Math.hypot((it.x-p.x)*720,(it.y-p.y)*1280)<it.z*.7){drag={it,moved:0};L.items.push(L.items.splice(i,1)[0]);break}}};
 cv.onpointermove=e=>{if(!L.ptr.has(e.pointerId))return;L.ptr.set(e.pointerId,e);
  if(L.ptr.size===2){const [a,b]=[...L.ptr.values()],d=Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY);L.zoom=Math.max(1,Math.min(4,pz*d/pd));$('#rZm').value=L.zoom;return}
  if(drag){const p=pos(e);drag.it.x=p.x;drag.it.y=p.y;drag.moved=1;$('#ltr').style.display='grid'}};
 const up=e=>{if(!L.ptr.has(e.pointerId))return;L.ptr.delete(e.pointerId);$('#ltr').style.display='none';
  if(drag){const p=pos(e);if(drag.moved&&p.y>.85)L.items.splice(L.items.indexOf(drag.it),1);else if(!drag.moved)drag.it.z=drag.it.z>200?70:drag.it.z*1.4;drag=null;return}
  if(e.type==='pointerup'&&!L.ptr.size&&Math.abs(e.clientX-sx)>60)setFx(L.fx+(e.clientX<sx?1:-1))};
 cv.onpointerup=up;cv.onpointercancel=up}
const mk=$('#mk');if(mk){mk.onclick=open}
const old=$('#cam');if(old)old.remove();
window.camStart=open;
})();

// Supabase project: eddyhutt@gmail.com's Project (eu-west-1)
// The anon key is public by design. Your data is protected by the Row Level Security policies already on your tables.
window.VISUAL_CONFIG = {
  SUPABASE_URL: "https://jncxfkpguotgfabobdzh.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpuY3hma3BndW90Z2ZhYm9iZHpoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM5NzkyOTUsImV4cCI6MjEwOTU1NTI5NX0.1I6KxGp5MxYYfff-6TXbKuKT3fjSw82MGe_7oCSk748"
};

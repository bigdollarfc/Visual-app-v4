# Simple local server using Python's built-in http.server
# No special assemblies required

$port = 8000
$folder = Get-Location

Write-Host "Serving $folder on http://localhost:$port" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop" -ForegroundColor Gray

# Try python3 first, then python
if (Get-Command python3 -ErrorAction SilentlyContinue) {
    python3 -m http.server $port
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    python -m http.server $port
} else {
    Write-Host "ERROR: Python is not installed. Please install Python or use VS Code Live Server instead." -ForegroundColor Red
    Write-Host "Or install Python from https://python.org and try again." -ForegroundColor Red
    pause
}

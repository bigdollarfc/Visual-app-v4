# Visual

Short-video social app prototype (plain HTML/CSS/JS, no build step).

- `index.html` markup, `styles.css` styles, `app.js` behavior
- `config.js` your Supabase URL and anon key (already filled in)
- `assets/logo-motion.mp4` logo animation on the login screen

## Run
Open the folder in VS Code and start the Live Server extension on `index.html` (use http://, not file://).

## Supabase
Uses your existing tables: `profiles` (display_name, bio), `videos` (caption, storage_path), plus the existing `video_likes`, `comments`, `follows`, `saves`, `reposts`, `messages`.
New accounts get a profile automatically from your `handle_new_user` trigger.
Quick scene posts use `storage_path = 'scene/<0-3>'`; camera recordings and selected video files are uploaded to Supabase Storage.
The For You and Following feeds use published Supabase videos only; the Live section remains available.
If "Confirm email" is on in Authentication settings, new users must click the email link before logging in.

### Storage setup
This app uploads videos to `arc-videos` and profile images to `arc-profiles`. Create both buckets and their upload policy by running [`supabase-setup.sql`](./supabase-setup.sql) in the Supabase SQL Editor. The buckets are public so published videos and profile images can load in the feed; uploads are limited to authenticated users' own user-ID folder.

## Loading state
While a video loads, buffers, or the connection drops, its card stays black and shows a small (30px) animated Visual logo (`assets/logo-loader.png`, transparent background). The logo pulses, glows and has a light sweep; on a slow or lost connection it also gets ripple rings and a "Slow connection…" / "No connection · waiting…" label. Network errors retry automatically (and when the device comes back online) instead of removing the card.

## Extras (`extras.js`)
- **Connection banner** – a pill at the top says "You're offline", "Slow connection" or "Back online" (uses `navigator.onLine`, the Network Information API where available, and video stall events).
- **Data saver** – the existing Settings switch now works: videos off-screen are not preloaded or auto-started; also honours the browser's own Save-Data setting.
- **Auto-scroll to next video** – new Settings switch; when on, videos stop looping and the feed scrolls to the next one when a video ends.

/* Visual — extras: connection banner, working Data saver, auto-scroll.
   Self-contained (IIFE) so it can't clash with names in app.js. Loaded last in index.html. */
(function(){
  'use strict';
  var root=document.documentElement, app=document.getElementById('app')||document.body;
  var feed=document.getElementById('feed');
  var q=function(s){return document.querySelector(s)}, qa=function(s){return Array.prototype.slice.call(document.querySelectorAll(s))};
  var say=function(m){try{if(typeof toast==='function')toast(m)}catch(e){}};
  var sw=function(label){return q('.sw[aria-label="'+label+'"]')};
  var isOn=function(label){var b=sw(label);return !!b&&b.getAttribute('aria-checked')==='true'};

  /* ============ FEATURE 1 — Connection banner + loader state ============ */
  var bar=document.createElement('div');
  bar.id='netbar';bar.setAttribute('role','status');bar.setAttribute('aria-live','polite');
  bar.innerHTML='<span class="vl"><img src="assets/logo-loader.png" alt="" width="20" height="20"></span><span class="dotn"></span><span id="netmsg"></span>';
  app.appendChild(bar);
  var hideT, stallT, state='ok';
  var conn=navigator.connection||navigator.mozConnection||navigator.webkitConnection;
  function weakLink(){
    if(!conn)return false;
    var t=conn.effectiveType;
    return t==='slow-2g'||t==='2g'||(conn.downlink!=null&&conn.downlink>0&&conn.downlink<0.6);
  }
  function show(kind,msg,autohide){
    bar.className=kind+' show';
    bar.querySelector('#netmsg').textContent=msg;
    clearTimeout(hideT);
    if(autohide)hideT=setTimeout(function(){bar.classList.remove('show')},autohide);
  }
  function evaluate(fromStall){
    var next=!navigator.onLine?'off':(fromStall||weakLink()?'slow':'ok');
    root.classList.toggle('net-off',next==='off');
    root.classList.toggle('net-slow',next==='slow');
    if(next==='off')show('off',"You're offline");
    else if(next==='slow')show('slow','Slow connection');
    else if(state!=='ok')show('ok','Back online',2200);
    else if(!bar.classList.contains('ok'))bar.classList.remove('show');
    state=next;
  }
  window.addEventListener('online',function(){evaluate(false)});
  window.addEventListener('offline',function(){evaluate(false)});
  if(conn&&conn.addEventListener)conn.addEventListener('change',function(){evaluate(false)});
  /* video stalls (media events don't bubble, so listen in the capture phase) */
  document.addEventListener('waiting',function(e){
    if(!(e.target&&e.target.classList&&e.target.classList.contains('vid')))return;
    evaluate(true);clearTimeout(stallT);stallT=setTimeout(function(){evaluate(false)},9000);
  },true);
  document.addEventListener('playing',function(e){
    if(!(e.target&&e.target.classList&&e.target.classList.contains('vid')))return;
    if(state==='slow'&&!weakLink()){clearTimeout(stallT);evaluate(false)}
  },true);
  evaluate(false);

  /* ============ FEATURE 2 — Data saver (the existing switch now works) ============ */
  function saverOn(){return isOn('Data saver')||!!(conn&&conn.saveData)}
  function applySaver(){
    var on=saverOn();
    qa('#feed .card').forEach(function(card){
      var v=card.querySelector('video.vid');if(!v)return;
      if(on&&!card.classList.contains('on')){v.preload='none';v.removeAttribute('autoplay')}
      else if(!on){v.preload='auto'}
    });
    root.classList.toggle('data-saver',on);
  }
  /* new cards (feed rebuilds) and cards that scroll into view */
  if(feed){
    new MutationObserver(applySaver).observe(feed,{childList:true});
    feed.addEventListener('scroll',function(){clearTimeout(applySaver._t);applySaver._t=setTimeout(applySaver,150)},{passive:true});
  }
  var ds=sw('Data saver');
  if(ds)ds.addEventListener('click',function(){
    applySaver();
    say(isOn('Data saver')?'Data saver on \u2014 videos load only when you reach them':'Data saver off');
  });
  applySaver();

  /* ============ FEATURE 3 — Auto-scroll to the next video ============ */
  function setLoop(){
    var auto=isOn('Auto-scroll');
    qa('#feed video.vid').forEach(function(v){v.loop=!auto});
  }
  var as=sw('Auto-scroll');
  if(as)as.addEventListener('click',function(){
    setLoop();
    say(isOn('Auto-scroll')?'Auto-scroll on \u2014 next video plays when this one ends':'Auto-scroll off \u2014 videos loop');
  });
  /* keep newly built cards in sync, and make sure a playing video isn't looping */
  document.addEventListener('play',function(e){
    var v=e.target;if(!v||!v.classList||!v.classList.contains('vid'))return;
    if(v.closest('#feed')&&isOn('Auto-scroll'))v.loop=false;
  },true);
  document.addEventListener('ended',function(e){
    var v=e.target;if(!v||!v.classList||!v.classList.contains('vid')||!isOn('Auto-scroll'))return;
    var card=v.closest('.card');if(!card||!card.classList.contains('on'))return;
    var next=card.nextElementSibling;
    if(next&&next.classList.contains('card'))next.scrollIntoView({behavior:'smooth',block:'start'});
    else{v.currentTime=0;var p=v.play();if(p&&p.catch)p.catch(function(){})} /* last video: replay it */
  },true);
  setLoop();
})();

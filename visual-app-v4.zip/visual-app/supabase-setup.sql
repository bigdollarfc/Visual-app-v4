create extension if not exists pgcrypto;

insert into storage.buckets (id, name, public)
values
  ('arc-videos', 'arc-videos', true),
  ('arc-profiles', 'arc-profiles', true)
on conflict (id) do update
set public = excluded.public;

drop policy if exists "Visual users upload their own media" on storage.objects;
create policy "Visual users upload their own media"
on storage.objects
for insert
to authenticated
with check (
  bucket_id in ('arc-videos', 'arc-profiles')
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Ensure profiles table exists (needed for auth users + feed joins)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  bio text,
  avatar_url text,
  banner_url text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- Columns the app reads/writes (older tables may not have them)
alter table public.profiles add column if not exists username text;
alter table public.profiles add column if not exists display_name text;
alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists banner_url text;
alter table public.profiles add column if not exists is_admin boolean not null default false;
alter table public.profiles add column if not exists verified boolean not null default false;
alter table public.profiles add column if not exists banned boolean not null default false;
alter table public.profiles add column if not exists suspended_until timestamptz;
alter table public.profiles add column if not exists admin_role text;
alter table public.profiles add column if not exists admin_perms jsonb not null default '{}'::jsonb;

-- Give every existing account a profile row
insert into public.profiles (id, username, display_name)
select u.id, split_part(u.email,'@',1) || '_' || substr(u.id::text,1,4), split_part(u.email,'@',1)
from auth.users u
where not exists (select 1 from public.profiles p where p.id = u.id)
on conflict do nothing;
drop policy if exists "profiles read public" on public.profiles;
create policy "profiles read public" on public.profiles for select to anon, authenticated using (true);
drop policy if exists "profiles insert own" on public.profiles;
create policy "profiles insert own" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profiles update own" on public.profiles;
create policy "profiles update own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Ensure videos table exists with all required columns
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  caption text,
  storage_path text,
  status text not null default 'published',
  promoted boolean not null default false,
  promoted_until timestamptz,
  likes_count integer not null default 0,
  comments_count integer not null default 0,
  saves_count integer not null default 0,
  shares_count integer not null default 0,
  created_at timestamptz not null default now()
);
alter table public.videos enable row level security;

-- Add missing columns if table already existed without them
alter table if exists public.videos add column if not exists status text not null default 'published';
alter table if exists public.videos add column if not exists promoted boolean not null default false;
alter table if exists public.videos add column if not exists promoted_until timestamptz;
alter table if exists public.videos add column if not exists likes_count integer not null default 0;
alter table if exists public.videos add column if not exists comments_count integer not null default 0;
alter table if exists public.videos add column if not exists saves_count integer not null default 0;
alter table if exists public.videos add column if not exists shares_count integer not null default 0;

-- Live engagement counters (safe if videos table exists)

-- Auto-create profile when a new user signs up
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  begin
    insert into public.profiles (id, username, display_name, bio)
    values (
      new.id,
      coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)) || '_' || substr(new.id::text,1,4),
      coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)),
      new.raw_user_meta_data->>'bio'
    )
    on conflict (id) do nothing;
  exception when others then
    -- never block sign-up because of a profile problem; the app creates the profile on first login
    raise warning 'handle_new_user failed: %', sqlerrm;
  end;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create table if not exists public.video_likes (
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (video_id, user_id)
);
create table if not exists public.video_saves (
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (video_id, user_id)
);
create table if not exists public.video_comments (
  id bigserial primary key,
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  parent_id bigint references public.video_comments(id) on delete cascade,
  body text not null,
  likes_count integer not null default 0,
  created_at timestamptz not null default now()
);
alter table if exists public.video_comments add column if not exists parent_id bigint references public.video_comments(id) on delete cascade;
alter table if exists public.video_comments add column if not exists likes_count integer not null default 0;

create table if not exists public.comment_likes (
  comment_id bigint not null references public.video_comments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

create table if not exists public.support_tickets (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  user_name text,
  subject text not null,
  status text not null default 'open' check (status in ('open','closed')),
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create table if not exists public.ticket_messages (
  id bigserial primary key,
  ticket_id bigint not null references public.support_tickets(id) on delete cascade,
  sender_role text not null default 'user' check (sender_role in ('user','admin')),
  user_id uuid references auth.users(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.video_likes enable row level security;
alter table public.video_saves enable row level security;
alter table public.video_comments enable row level security;
alter table public.comment_likes enable row level security;
alter table public.support_tickets enable row level security;
alter table public.ticket_messages enable row level security;

-- video interactions (publicly readable; writes by authenticated owner)
drop policy if exists "likes read" on public.video_likes;
create policy "likes read" on public.video_likes for select to anon, authenticated using (true);
drop policy if exists "likes insert own" on public.video_likes;
create policy "likes insert own" on public.video_likes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "likes delete own" on public.video_likes;
create policy "likes delete own" on public.video_likes for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "saves read own" on public.video_saves;
create policy "saves read own" on public.video_saves for select to authenticated using (auth.uid() = user_id);
drop policy if exists "saves insert own" on public.video_saves;
create policy "saves insert own" on public.video_saves for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "saves delete own" on public.video_saves;
create policy "saves delete own" on public.video_saves for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "comments read" on public.video_comments;
create policy "comments read" on public.video_comments for select to anon, authenticated using (true);
drop policy if exists "comments insert own" on public.video_comments;
create policy "comments insert own" on public.video_comments for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "comments delete own" on public.video_comments;
create policy "comments delete own" on public.video_comments for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "comment likes read" on public.comment_likes;
create policy "comment likes read" on public.comment_likes for select to anon, authenticated using (true);
drop policy if exists "comment likes insert own" on public.comment_likes;
create policy "comment likes insert own" on public.comment_likes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "comment likes delete own" on public.comment_likes;
create policy "comment likes delete own" on public.comment_likes for delete to authenticated using (auth.uid() = user_id);

-- tickets: owner or admin (profiles.is_admin)
drop policy if exists "tickets read own or admin" on public.support_tickets;
create policy "tickets read own or admin" on public.support_tickets for select to authenticated
using (auth.uid() = user_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));
drop policy if exists "tickets insert own" on public.support_tickets;
create policy "tickets insert own" on public.support_tickets for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "tickets update own or admin" on public.support_tickets;
create policy "tickets update own or admin" on public.support_tickets for update to authenticated
using (auth.uid() = user_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin))
with check (auth.uid() = user_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

drop policy if exists "ticket msgs read own or admin" on public.ticket_messages;
create policy "ticket msgs read own or admin" on public.ticket_messages for select to authenticated
using (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = auth.uid() or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin))));
drop policy if exists "ticket msgs insert own or admin" on public.ticket_messages;
create policy "ticket msgs insert own or admin" on public.ticket_messages for insert to authenticated
with check (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = auth.uid() or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin))));

-- allow authenticated users to update video counters (simple app-driven counters)
drop policy if exists "videos update counters" on public.videos;
create policy "videos update counters" on public.videos for update to authenticated
using (true) with check (true);

-- helper RPCs for atomic-ish increments
create or replace function public.bump_video_counter(vid uuid, field text, delta int)
returns void language plpgsql security definer as $$
begin
  if field = 'likes_count' then update public.videos set likes_count = greatest(0, coalesce(likes_count,0)+delta) where id = vid;
  elsif field = 'comments_count' then update public.videos set comments_count = greatest(0, coalesce(comments_count,0)+delta) where id = vid;
  elsif field = 'saves_count' then update public.videos set saves_count = greatest(0, coalesce(saves_count,0)+delta) where id = vid;
  elsif field = 'shares_count' then update public.videos set shares_count = greatest(0, coalesce(shares_count,0)+delta) where id = vid;
  end if;
end; $$;
grant execute on function public.bump_video_counter(uuid,text,int) to authenticated;

create or replace function public.bump_comment_counter(cid bigint, delta int)
returns void language plpgsql security definer as $$
begin
  update public.video_comments set likes_count = greatest(0, coalesce(likes_count,0)+delta) where id = cid;
end; $$;
grant execute on function public.bump_comment_counter(bigint,int) to authenticated;

-- feeds/profile reads (public). Adjust if you require stricter visibility.
drop policy if exists "videos read public" on public.videos;
create policy "videos read public" on public.videos for select to anon, authenticated using (status = 'published');
drop policy if exists "profiles read public" on public.profiles;
create policy "profiles read public" on public.profiles for select to anon, authenticated using (true);
create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);
alter table public.follows enable row level security;
drop policy if exists "follows read" on public.follows;
create policy "follows read" on public.follows for select to anon, authenticated using (true);
drop policy if exists "follows insert own" on public.follows;
create policy "follows insert own" on public.follows for insert to authenticated with check (auth.uid() = follower_id);
drop policy if exists "follows delete own" on public.follows;
create policy "follows delete own" on public.follows for delete to authenticated using (auth.uid() = follower_id);


-- Make videos.user_id relate to profiles (lets the feed join author names/avatars)
insert into public.profiles (id, username, display_name)
select distinct v.user_id, 'user_' || substr(v.user_id::text,1,8), 'Visual user'
from public.videos v
where not exists (select 1 from public.profiles p where p.id = v.user_id)
  and exists (select 1 from auth.users u where u.id = v.user_id)
on conflict do nothing;
alter table public.videos drop constraint if exists videos_user_id_fkey;
alter table public.videos add constraint videos_user_id_fkey foreign key (user_id) references public.profiles(id) on delete cascade;

-- Make sure published videos can be read by everyone, and the buckets are public
update storage.buckets set public = true where id in ('arc-videos','arc-profiles');

-- ===== Admin panel support =====
alter table public.profiles add column if not exists strikes integer not null default 0;
alter table public.profiles add column if not exists coins integer not null default 0;
alter table public.profiles add column if not exists last_claim timestamptz;
alter table public.profiles add column if not exists status_note text;

create or replace function public.is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from public.profiles where id=auth.uid() and is_admin) $$;
grant execute on function public.is_admin() to authenticated;

drop policy if exists "admin update profiles" on public.profiles;
create policy "admin update profiles" on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin read all videos" on public.videos;
create policy "admin read all videos" on public.videos for select to authenticated using (public.is_admin());
drop policy if exists "admin delete videos" on public.videos;
create policy "admin delete videos" on public.videos for delete to authenticated using (public.is_admin() or auth.uid()=user_id);
drop policy if exists "admin delete comments" on public.video_comments;
create policy "admin delete comments" on public.video_comments for delete to authenticated using (public.is_admin() or auth.uid()=user_id);
-- make yourself the owner (replace the email):
-- update public.profiles set is_admin=true, admin_role='owner' where id=(select id from auth.users where email='you@email.com');
